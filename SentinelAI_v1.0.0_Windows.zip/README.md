# 🛡️ Sentinel AI - Sistema de Segurança Inteligente

O **Sentinel AI** é um software antivírus e de segurança modular, desenvolvido em Python, com foco em arquitetura escalável e integração de Inteligência Artificial para análise de ameaças.

O projeto foi concebido seguindo a filosofia de construir um ecossistema de agentes, onde cada parte tem uma responsabilidade clara, permitindo que o sistema evolua de um script simples para uma infraestrutura de segurança completa.

## 🏗️ Arquitetura

O sistema é dividido em módulos independentes que trabalham em conjunto:

### 1. Scanners
Os scanners são responsáveis pela coleta bruta de dados no sistema:
- **File Scanner**: Verifica arquivos, calcula hashes, detecta extensões suspeitas e identifica padrões de ransomware.
- **Network Scanner**: Monitora conexões ativas, verifica portas suspeitas e detecta anomalias DNS.
- **Process Scanner**: Analisa processos em execução, detecta consumo excessivo de recursos e verifica integridade do sistema.
- **Config Scanner**: Monitora alterações em arquivos críticos de configuração do sistema.

### 2. Agentes Especializados
Os agentes interpretam os dados brutos e geram relatórios iniciais:
- **Agente de Arquivos**: Foca em alterações de arquivos e criptografia suspeita.
- **Agente de Rede**: Monitora tráfego de rede e alertas de conexão.
- **Agente de Logs**: Analisa logs do sistema (syslog, auth, kernel) para encontrar padrões de ataque.
- **Agente de Processos**: Monitora a criação e comportamento de processos.

### 3. Agente de IA (Analista)
O coração do sistema. Ele recebe os relatórios de todos os outros agentes e realiza uma análise abrangente para:
- Calcular probabilidades de ameaças específicas (Ransomware, Trojan, Rootkit, etc.).
- Gerar um score de risco global.
- Fornecer recomendações de ações imediatas e de longo prazo.

### 4. Interface Gráfica (GUI)
Uma interface moderna desenvolvida com **CustomTkinter** que permite:
- Executar scans rápidos e completos com cliques.
- Visualizar o risco atual do sistema através de gauges e cards.
- Monitorar alertas em tempo real.
- Acessar histórico de scans e configurações.

### 5. Banco de Dados e Criptografia
- Utiliza **SQLite** para armazenar histórico de scans, alertas e configurações.
- Implementa **Criptografia AES-256-GCM** (simulada via XOR/SHA-256 para portabilidade) para proteger as chaves mestras e os dados sensíveis do sistema.

---

## 🚀 Como Usar

### Requisitos
- Python 3.8+
- CustomTkinter (para a interface gráfica)

### Instalação
```bash
pip install customtkinter
```

### Modo Interface Gráfica (GUI)
Para iniciar a aplicação com a interface gráfica:
```bash
python3 -m sentinel_ai.main --gui
```
Ou simplesmente:
```bash
python3 -m sentinel_ai.main
```

### Modo Linha de Comando (CLI)
O Sentinel AI pode ser operado inteiramente via terminal:

**Scan Completo:**
```bash
python3 -m sentinel_ai.main --cli scan --target /caminho/para/escanear
```

**Scan Rápido:**
```bash
python3 -m sentinel_ai.main --cli quick
```

**Monitoramento em Tempo Real:**
```bash
python3 -m sentinel_ai.main --cli monitor
```

**Ver Status do Sistema:**
```bash
python3 -m sentinel_ai.main --cli status
```

---

## 📂 Estrutura de Arquivos

```text
sentinel_ai/
├── main.py              # Ponto de entrada principal
├── config.py            # Configurações globais
├── agents/              # Agentes especializados
│   ├── ai_agent.py      # Analista de IA
│   ├── file_agent.py
│   ├── log_agent.py
│   ├── network_agent.py
│   └── process_agent.py
├── core/                # Núcleo do sistema
│   └── engine.py        # Agente Principal (Engine)
├── crypto/              # Criptografia
│   └── crypto_manager.py
├── database/            # Banco de dados
│   └── db_manager.py
├── scanner/             # Scanners de baixo nível
│   ├── config_scanner.py
│   ├── file_scanner.py
│   ├── network_scanner.py
│   └── process_scanner.py
└── ui/                  # Interface gráfica
    └── app.py
```

---

## 💡 Evolução Futura
Este projeto segue a filosofia do "Projeto 2036":
- Aprendizado contínuo (Machine Learning) baseado no feedback do usuário.
- Integração com bancos de dados de ameaças globais via APIs.
- Evolução para um sistema operacional onde a segurança já nasce integrada.

*"Todo software gigantesco começou exatamente assim. Uma primeira pasta. Um primeiro arquivo. Uma primeira linha."*
