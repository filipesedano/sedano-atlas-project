#!/usr/bin/env python3
"""
Sentinel AI - Launcher Principal
Ponto de entrada para o executável empacotado.
"""

import os
import sys
import platform

# Determinar base path (funciona tanto no dev quanto no PyInstaller)
if getattr(sys, 'frozen', False):
    BASE_DIR = sys._MEIPASS
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

sys.path.insert(0, BASE_DIR)

def main():
    """Função principal do launcher."""
    # Verificar sistema operacional
    os_name = platform.system().lower()

    # Criar diretório de dados do usuário
    if os_name == "windows":
        app_data = os.environ.get('APPDATA', os.path.expanduser('~'))
        data_dir = os.path.join(app_data, 'SentinelAI')
    elif os_name == "darwin":
        data_dir = os.path.join(os.path.expanduser('~'), 'Library', 'Application Support', 'SentinelAI')
    else:
        data_dir = os.path.join(os.path.expanduser('~'), '.sentinel_ai')

    os.makedirs(data_dir, exist_ok=True)

    # Setar variável de ambiente para o diretório de dados
    os.environ['SENTINEL_DATA_DIR'] = data_dir

    print("=" * 60)
    print("  SENTINEL AI - Sistema de Segurança Inteligente")
    print("  Versão 1.0.0")
    print("=" * 60)
    print()

    # Verificar modo de execução
    if len(sys.argv) > 1:
        if sys.argv[1] == "--cli":
            run_cli_mode(data_dir)
        elif sys.argv[1] == "--gui":
            run_gui_mode()
        elif sys.argv[1] == "--scan":
            run_scan_mode(data_dir)
        else:
            show_help()
    else:
        # Padrão: tentar GUI primeiro, fallback para CLI
        run_gui_mode()


def run_gui_mode():
    """Executa a interface gráfica."""
    print("Iniciando Interface Gráfica...")
    try:
        from sentinel_ai.ui.app import SentinelApp
        app = SentinelApp()
        app.run()
    except ImportError as e:
        print(f"Erro ao carregar GUI: {e}")
        print("Tentando modo CLI...")
        run_cli_mode(os.environ.get('SENTINEL_DATA_DIR'))


def run_cli_mode(data_dir):
    """Executa em modo CLI."""
    from sentinel_ai.core.engine import SentinelEngine, dataclass_to_dict
    from sentinel_ai.config import config
    from sentinel_ai.database.db_manager import DatabaseManager
    from sentinel_ai.crypto.crypto_manager import CryptoManager
    from datetime import datetime

    engine = SentinelEngine()
    engine.initialize()
    crypto = CryptoManager()
    crypto.ensure_key_exists()

    print("\n[1/4] Scanner de Arquivos...")
    file_report = engine.file_agent.full_scan(os.path.expanduser("~"))
    print(f"   → {file_report.total_files_scanned} arquivos escaneados")
    print(f"   → {file_report.suspicious_files} arquivos suspeitos")

    print("\n[2/4] Scanner de Rede...")
    network_report = engine.network_agent.full_scan()
    print(f"   → {network_report.total_connections} conexões ativas")
    print(f"   → {network_report.suspicious_connections} conexões suspeitas")

    print("\n[3/4] Scanner de Processos...")
    process_report = engine.process_agent.full_scan()
    print(f"   → {process_report.total_processes} processos ativos")
    print(f"   → {process_report.suspicious_processes} processos suspeitos")

    print("\n[4/4] Análise de Logs...")
    log_report = engine.log_agent.scan_system_logs()
    print(f"   → {log_report.total_events_analyzed} eventos analisados")

    print("\n[IA] Analisando resultados...")
    comprehensive = engine.ai_agent.analyze_all_data(
        file_report=dataclass_to_dict(file_report),
        network_report=dataclass_to_dict(network_report),
        log_report=dataclass_to_dict(log_report),
        process_report=dataclass_to_dict(process_report)
    )

    print(f"\n  Risco Geral: {comprehensive.overall_risk_score:.1f}%")
    print(f"  Ameaças: {comprehensive.threat_count}")
    print(f"  Resumo: {comprehensive.summary}")

    if comprehensive.threats:
        for threat in comprehensive.threats:
            print(f"    • {threat.threat_type}: {threat.probability:.1f}%")

    if comprehensive.immediate_actions:
        print("\n  Ações Imediatas:")
        for action in comprehensive.immediate_actions:
            print(f"    ⚡ {action}")

    print("\n" + "=" * 60)


def run_scan_mode(data_dir):
    """Executa scan rápido."""
    from sentinel_ai.core.engine import SentinelEngine, dataclass_to_dict
    from sentinel_ai.crypto.crypto_manager import CryptoManager

    engine = SentinelEngine()
    engine.initialize()
    crypto = CryptoManager()
    crypto.ensure_key_exists()

    report = engine.quick_scan()
    print(f"\n  Risco: {report.overall_risk_score:.1f}%")
    print(f"  Ameaças: {report.threat_count}")
    print(f"  {report.summary}")


def show_help():
    """Mostra ajuda."""
    print("""
Comandos disponíveis:
  (sem argumentos)    Iniciar Interface Gráfica
  --gui               Forçar Interface Gráfica
  --cli               Executar Scan Completo via CLI
  --scan              Executar Scan Rápido via CLI

Exemplos:
  SentinelAI.exe --cli
  SentinelAI.exe --scan
    """)


if __name__ == "__main__":
    main()
