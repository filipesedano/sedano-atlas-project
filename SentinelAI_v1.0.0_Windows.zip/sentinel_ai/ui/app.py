"""
Interface Gráfica do Sentinel AI.
Usa CustomTkinter para uma interface moderna e responsiva.
"""

import os
import sys
import time
import threading
import logging
import tkinter as tk
from tkinter import messagebox, filedialog
from typing import Dict, Optional
from datetime import datetime

try:
    import customtkinter as ctk
    CTK_AVAILABLE = True
except ImportError:
    CTK_AVAILABLE = False
    print("CustomTkinter não instalado. Usando tkinter padrão.")

from ..core.engine import SentinelEngine, EngineStatus
from ..config import config
from ..database.db_manager import DatabaseManager
from ..crypto.crypto_manager import CryptoManager

logger = logging.getLogger("sentinel.ui")


# ============================================================================
# CORES E TEMA
# ============================================================================

COLORS = {
    "dark_bg": "#1a1a2e",
    "dark_card": "#16213e",
    "dark_card_hover": "#0f3460",
    "accent_green": "#00ff88",
    "accent_yellow": "#ffcc00",
    "accent_orange": "#ff8800",
    "accent_red": "#ff4444",
    "accent_blue": "#0088ff",
    "accent_purple": "#8844ff",
    "text_primary": "#ffffff",
    "text_secondary": "#8899aa",
    "text_muted": "#556677",
    "border": "#2a2a4e",
    "success": "#00cc66",
    "warning": "#ffaa00",
    "danger": "#ff3333",
    "info": "#0088ff",
}


# ============================================================================
# COMPONENTES REUTILIZÁVEIS
# ============================================================================

class ThreatCard:
    """Card de ameaça para exibição na UI."""

    def __init__(self, parent, threat_data: Dict):
        self.parent = parent
        self.data = threat_data
        self.frame = None
        self._create_widget()

    def _create_widget(self):
        if not CTK_AVAILABLE:
            return

        severity = self.data.get("risk_level", "medium")
        color_map = {
            "critical": COLORS["accent_red"],
            "high": COLORS["accent_orange"],
            "medium": COLORS["accent_yellow"],
            "low": COLORS["accent_green"],
        }
        color = color_map.get(severity, COLORS["accent_blue"])

        self.frame = ctk.CTkFrame(
            self.parent,
            fg_color=COLORS["dark_card"],
            corner_radius=10,
            border_width=2,
            border_color=color
        )

        # Nome da ameaça
        label_name = ctk.CTkLabel(
            self.frame,
            text=self.data.get("threat_type", "Unknown").upper(),
            font=ctk.CTkFont(size=14, weight="bold"),
            text_color=color,
            anchor="w"
        )
        label_name.pack(fill="x", padx=15, pady=(10, 2))

        # Descrição
        label_desc = ctk.CTkLabel(
            self.frame,
            text=self.data.get("description", ""),
            font=ctk.CTkFont(size=11),
            text_color=COLORS["text_secondary"],
            anchor="w",
            wraplength=300
        )
        label_desc.pack(fill="x", padx=15)

        # Probabilidade
        prob = self.data.get("probability", 0)
        progress = ctk.CTkProgressBar(
            self.frame,
            width=280,
            height=8,
            fg_color=COLORS["border"],
            progress_color=color
        )
        progress.pack(padx=15, pady=(8, 2))
        progress.set(prob / 100)

        label_prob = ctk.CTkLabel(
            self.frame,
            text=f"Probabilidade: {prob:.1f}%",
            font=ctk.CTkFont(size=10),
            text_color=color,
            anchor="w"
        )
        label_prob.pack(fill="x", padx=15, pady=(0, 10))


class RiskGauge:
    """Medidor de risco visual."""

    def __init__(self, parent, size=150):
        self.parent = parent
        self.size = size
        self.canvas = None
        self.current_value = 0
        self._create_widget()

    def _create_widget(self):
        self.canvas = tk.Canvas(
            self.parent,
            width=self.size,
            height=self.size,
            bg=COLORS["dark_bg"],
            highlightthickness=0
        )
        self.canvas.pack(pady=10)
        self.update(0)

    def update(self, value: float):
        """Atualiza o medidor."""
        self.current_value = value
        self.canvas.delete("all")

        cx, cy = self.size // 2, self.size // 2
        r = self.size // 2 - 10

        # Background arc
        self.canvas.create_arc(
            cx - r, cy - r, cx + r, cy + r,
            start=0, extent=180, style="arc",
            width=15, outline=COLORS["border"]
        )

        # Determine color
        if value < 30:
            color = COLORS["success"]
        elif value < 60:
            color = COLORS["warning"]
        else:
            color = COLORS["danger"]

        # Value arc
        angle = int((value / 100) * 180)
        if angle > 0:
            self.canvas.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=180 - angle, extent=angle, style="arc",
                width=15, outline=color
            )

        # Center text
        self.canvas.create_text(
            cx, cy - 5,
            text=f"{value:.0f}%",
            font=("Arial", 24, "bold"),
            fill=color
        )
        self.canvas.create_text(
            cx, cy + 20,
            text="RISCO",
            font=("Arial", 10),
            fill=COLORS["text_secondary"]
        )


class ActivityLog:
    """Log de atividade em tempo real."""

    def __init__(self, parent, height=200):
        self.parent = parent
        self.height = height
        self.text_widget = None
        self.entries = []
        self._create_widget()

    def _create_widget(self):
        if CTK_AVAILABLE:
            self.text_widget = ctk.CTkTextbox(
                self.parent,
                height=self.height,
                font=ctk.CTkFont(family="Consolas", size=10),
                fg_color=COLORS["dark_card"],
                text_color=COLORS["text_secondary"]
            )
        else:
            self.text_widget = tk.Text(
                self.parent,
                height=12,
                font=("Consolas", 10),
                bg=COLORS["dark_card"],
                fg=COLORS["text_secondary"]
            )
        self.text_widget.pack(fill="both", expand=True, padx=10, pady=5)

    def add_entry(self, message: str, level: str = "info"):
        """Adiciona entrada ao log."""
        timestamp = datetime.now().strftime("%H:%M:%S")
        color_map = {
            "critical": COLORS["accent_red"],
            "high": COLORS["accent_orange"],
            "warning": COLORS["accent_yellow"],
            "info": COLORS["text_secondary"],
        }
        color = color_map.get(level, COLORS["text_secondary"])

        entry = f"[{timestamp}] [{level.upper():>8}] {message}"
        self.entries.append(entry)

        # Limitar entradas
        if len(self.entries) > 200:
            self.entries = self.entries[-150:]

        self.text_widget.configure(state="normal")
        self.text_widget.insert("end", entry + "\n")
        self.text_widget.see("end")
        self.text_widget.configure(state="disabled")

    def clear(self):
        """Limpa o log."""
        self.entries.clear()
        self.text_widget.configure(state="normal")
        self.text_widget.delete("1.0", "end")
        self.text_widget.configure(state="disabled")


# ============================================================================
# APLICAÇÃO PRINCIPAL
# ============================================================================

class SentinelApp:
    """Aplicação principal do Sentinel AI."""

    def __init__(self):
        self.engine = SentinelEngine()
        self.db = self.engine.db
        self.crypto = CryptoManager()
        self._scan_in_progress = False
        self._monitoring = False

        # Configurar logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )

        # Inicializar engine
        self.engine.initialize()

        # Registrar callbacks
        self.engine.register_callback("scan_started", self._on_scan_started)
        self.engine.register_callback("scan_completed", self._on_scan_completed)
        self.engine.register_callback("network_alert", self._on_network_alert)
        self.engine.register_callback("process_alert", self._on_process_alert)

        # Criar interface
        self._setup_ui()

    def _setup_ui(self):
        """Configura a interface gráfica."""
        if CTK_AVAILABLE:
            ctk.set_appearance_mode("dark")
            ctk.set_default_color_theme("blue")
            self.root = ctk.CTk()
        else:
            self.root = tk.Tk()

        self.root.title("Sentinel AI - Sistema de Segurança")
        self.root.geometry("1200x800")
        self.root.configure(bg=COLORS["dark_bg"])

        # Criar componentes
        self._create_sidebar()
        self._create_main_area()
        self._create_status_bar()

        # Iniciar log
        self.activity_log.add_entry("Sentinel AI inicializado com sucesso", "info")
        self.activity_log.add_entry("Motor de segurança pronto", "info")

    def _create_sidebar(self):
        """Cria a barra lateral de navegação."""
        sidebar_width = 200

        if CTK_AVAILABLE:
            self.sidebar = ctk.CTkFrame(
                self.root,
                width=sidebar_width,
                fg_color=COLORS["dark_card"],
                corner_radius=0
            )
        else:
            self.sidebar = tk.Frame(self.root, width=sidebar_width, bg=COLORS["dark_card"])
        self.sidebar.pack(side="left", fill="y")
        self.sidebar.pack_propagate(False)

        # Logo/Título
        if CTK_AVAILABLE:
            title = ctk.CTkLabel(
                self.sidebar,
                text="🛡️ SENTINEL AI",
                font=ctk.CTkFont(size=18, weight="bold"),
                text_color=COLORS["accent_blue"],
                pady=20
            )
        else:
            title = tk.Label(
                self.sidebar,
                text="🛡️ SENTINEL AI",
                font=("Arial", 18, "bold"),
                bg=COLORS["dark_card"],
                fg=COLORS["accent_blue"]
            )
        title.pack(pady=(20, 10))

        subtitle = ctk.CTkLabel(
            self.sidebar,
            text="Sistema de Segurança",
            font=ctk.CTkFont(size=11),
            text_color=COLORS["text_muted"]
        ) if CTK_AVAILABLE else tk.Label(
            self.sidebar,
            text="Sistema de Segurança",
            font=("Arial", 11),
            bg=COLORS["dark_card"],
            fg=COLORS["text_muted"]
        )
        subtitle.pack()

        # Botões de navegação
        self._create_nav_button("Dashboard", "📊", self._show_dashboard)
        self._create_nav_button("Scan Completo", "🔍", self._start_full_scan)
        self._create_nav_button("Scan Rápido", "⚡", self._start_quick_scan)
        self._create_nav_button("Monitoramento", "📡", self._toggle_monitoring)
        self._create_nav_button("Relatórios", "📋", self._show_reports)
        self._create_nav_button("Configurações", "⚙️", self._show_settings)

        # Separador
        separator = ctk.CTkFrame(
            self.sidebar, height=1, fg_color=COLORS["border"]
        ) if CTK_AVAILABLE else tk.Frame(
            self.sidebar, height=1, bg=COLORS["border"]
        )
        separator.pack(fill="x", padx=10, pady=10)

        # Status da conexão
        status_label = ctk.CTkLabel(
            self.sidebar,
            text="● Online",
            font=ctk.CTkFont(size=11),
            text_color=COLORS["accent_green"]
        ) if CTK_AVAILABLE else tk.Label(
            self.sidebar,
            text="● Online",
            font=("Arial", 11),
            bg=COLORS["dark_card"],
            fg=COLORS["accent_green"]
        )
        status_label.pack(pady=5)

    def _create_nav_button(self, text: str, icon: str, command):
        """Cria botão de navegação."""
        if CTK_AVAILABLE:
            btn = ctk.CTkButton(
                self.sidebar,
                text=f"  {icon}  {text}",
                command=command,
                fg_color="transparent",
                hover_color=COLORS["dark_card_hover"],
                text_color=COLORS["text_primary"],
                font=ctk.CTkFont(size=13),
                height=40,
                corner_radius=8
            )
        else:
            btn = tk.Button(
                self.sidebar,
                text=f"  {icon}  {text}",
                command=command,
                bg=COLORS["dark_card"],
                fg=COLORS["text_primary"],
                activebackground=COLORS["dark_card_hover"],
                activeforeground=COLORS["text_primary"],
                font=("Arial", 13),
                height=2,
                relief="flat"
            )
        btn.pack(fill="x", padx=5, pady=2)

    def _create_main_area(self):
        """Cria a área principal de conteúdo."""
        if CTK_AVAILABLE:
            self.main_frame = ctk.CTkFrame(
                self.root,
                fg_color=COLORS["dark_bg"],
                corner_radius=0
            )
        else:
            self.main_frame = tk.Frame(self.root, bg=COLORS["dark_bg"])
        self.main_frame.pack(side="right", fill="both", expand=True)

        # Frame para conteúdo dinâmico
        if CTK_AVAILABLE:
            self.content_frame = ctk.CTkScrollableFrame(
                self.main_frame,
                fg_color=COLORS["dark_bg"]
            )
        else:
            self.content_frame = tk.Frame(self.main_frame, bg=COLORS["dark_bg"])
            # Adicionar scrollbar
            scrollbar = tk.Scrollbar(self.main_frame, orient="vertical")
            scrollbar.pack(side="right", fill="y")
            self.content_frame.configure(yscrollcommand=scrollbar.set)
            scrollbar.config(command=self.content_frame.yview)

        self.content_frame.pack(fill="both", expand=True, padx=15, pady=15)

        # Mostrar dashboard inicial
        self._show_dashboard()

    def _create_status_bar(self):
        """Cria barra de status inferior."""
        if CTK_AVAILABLE:
            self.status_bar = ctk.CTkFrame(
                self.root,
                height=30,
                fg_color=COLORS["dark_card"],
                corner_radius=0
            )
        else:
            self.status_bar = tk.Frame(self.root, height=30, bg=COLORS["dark_card"])
        self.status_bar.pack(side="bottom", fill="x")
        self.status_bar.pack_propagate(False)

        self.status_label = ctk.CTkLabel(
            self.status_bar,
            text=" Pronta para uso | Última verificação: -",
            font=ctk.CTkFont(size=10),
            text_color=COLORS["text_muted"],
            anchor="w"
        ) if CTK_AVAILABLE else tk.Label(
            self.status_bar,
            text=" Pronta para uso | Última verificação: -",
            font=("Arial", 10),
            bg=COLORS["dark_card"],
            fg=COLORS["text_muted"],
            anchor="w"
        )
        self.status_label.pack(fill="x", padx=10, pady=5)

    # ========================================================================
    # PÁGINAS / VIEWS
    # ========================================================================

    def _show_dashboard(self):
        """Exibe o dashboard principal."""
        self._clear_content()

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text="Dashboard",
                font=ctk.CTkFont(size=24, weight="bold"),
                text_color=COLORS["text_primary"],
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text="Dashboard",
                font=("Arial", 24, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["text_primary"],
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        # Cards de status em grid
        cards_frame = ctk.CTkFrame(
            self.content_frame, fg_color="transparent"
        ) if CTK_AVAILABLE else tk.Frame(self.content_frame, bg=COLORS["dark_bg"])
        cards_frame.pack(fill="x")

        # Obter estatísticas
        try:
            stats = self.db.get_statistics()
        except Exception:
            stats = {"total_scans": 0, "critical_alerts": 0, "average_risk_score": 0}

        # Card: Total Scans
        self._create_stat_card(
            cards_frame, "Total Scans", str(stats.get("total_scans", 0)),
            COLORS["accent_blue"], "🔍"
        )

        # Card: Ameaças
        self._create_stat_card(
            cards_frame, "Ameaças Críticas", str(stats.get("critical_alerts", 0)),
            COLORS["accent_red"], "⚠️"
        )

        # Card: Risco Médio
        self._create_stat_card(
            cards_frame, "Risco Médio", f"{stats.get('average_risk_score', 0):.1f}%",
            COLORS["accent_yellow"], "📊"
        )

        # Card: Status
        risk = self.engine.get_status().system_risk_score
        risk_color = COLORS["accent_green"] if risk < 30 else (
            COLORS["accent_yellow"] if risk < 60 else COLORS["accent_red"]
        )
        self._create_stat_card(
            cards_frame, "Risco Atual", f"{risk:.1f}%",
            risk_color, "🛡️"
        )

        # Log de atividade
        log_header = ctk.CTkLabel(
            self.content_frame,
            text="Log de Atividade",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLORS["text_primary"],
            anchor="w"
        ) if CTK_AVAILABLE else tk.Label(
            self.content_frame,
            text="Log de Atividade",
            font=("Arial", 16, "bold"),
            bg=COLORS["dark_bg"],
            fg=COLORS["text_primary"],
            anchor="w"
        )
        log_header.pack(fill="x", pady=(20, 5))

        # Criar log widget
        self.activity_log = ActivityLog(self.content_frame, height=150)

        # Atualizar status bar
        self._update_status_bar("Dashboard ativo")

    def _create_stat_card(self, parent, title: str, value: str, color: str, icon: str):
        """Cria card de estatística."""
        if CTK_AVAILABLE:
            card = ctk.CTkFrame(
                parent,
                width=220,
                height=100,
                fg_color=COLORS["dark_card"],
                corner_radius=10,
                border_width=1,
                border_color=color
            )
            card.pack(side="left", padx=8, pady=5)
            card.pack_propagate(False)

            icon_label = ctk.CTkLabel(
                card, text=icon, font=ctk.CTkFont(size=28)
            )
            icon_label.pack(pady=(15, 5))

            value_label = ctk.CTkLabel(
                card, text=value, font=ctk.CTkFont(size=22, weight="bold"),
                text_color=color
            )
            value_label.pack()

            title_label = ctk.CTkLabel(
                card, text=title, font=ctk.CTkFont(size=11),
                text_color=COLORS["text_muted"]
            )
            title_label.pack(pady=(5, 10))
        else:
            card = tk.Frame(
                parent, width=220, height=100, bg=COLORS["dark_card"],
                bd=1, relief="solid"
            )
            card.pack(side="left", padx=8, pady=5)
            card.pack_propagate(False)

            tk.Label(card, text=icon, font=("Arial", 28), bg=COLORS["dark_card"]).pack(pady=(15, 5))
            tk.Label(card, text=value, font=("Arial", 22, "bold"),
                     bg=COLORS["dark_card"], fg=color).pack()
            tk.Label(card, text=title, font=("Arial", 11),
                     bg=COLORS["dark_card"], fg=COLORS["text_muted"]).pack(pady=(5, 10))

    def _start_full_scan(self):
        """Inicia scan completo."""
        if self._scan_in_progress:
            messagebox.showwarning("Aviso", "Um scan já está em progresso!")
            return

        # Selecionar diretório
        scan_path = filedialog.askdirectory(title="Selecionar diretório para scan")
        if not scan_path:
            scan_path = os.path.expanduser("~")

        self._scan_in_progress = True
        self._clear_content()

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text="🔍 Scan Completo em Progresso...",
                font=ctk.CTkFont(size=20, weight="bold"),
                text_color=COLORS["accent_blue"],
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text="🔍 Scan Completo em Progresso...",
                font=("Arial", 20, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["accent_blue"],
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        # Barra de progresso
        if CTK_AVAILABLE:
            self.scan_progress = ctk.CTkProgressBar(
                self.content_frame, width=400, height=20,
                fg_color=COLORS["border"],
                progress_color=COLORS["accent_blue"]
            )
        else:
            self.scan_progress = None

        # Log do scan
        self.scan_log = ActivityLog(self.content_frame, height=300)

        # Executar scan em thread
        threading.Thread(
            target=self._run_full_scan,
            args=(scan_path,),
            daemon=True
        ).start()

        self._update_status_bar(f"Scan completo iniciado: {scan_path}")

    def _start_quick_scan(self):
        """Inicia scan rápido."""
        if self._scan_in_progress:
            messagebox.showwarning("Aviso", "Um scan já está em progresso!")
            return

        self._scan_in_progress = True
        threading.Thread(target=self._run_quick_scan, daemon=True).start()
        self._update_status_bar("Scan rápido iniciado")
        self.activity_log.add_entry("Scan rápido iniciado", "info")

    def _toggle_monitoring(self):
        """Alterna monitoramento em tempo real."""
        if self._monitoring:
            self.engine.stop_real_time_monitoring()
            self._monitoring = False
            self.activity_log.add_entry("Monitoramento parado", "warning")
        else:
            self.engine.start_real_time_monitoring()
            self._monitoring = True
            self.activity_log.add_entry("Monitoramento em tempo real iniciado", "info")

    def _show_reports(self):
        """Exibe relatórios de scans anteriores."""
        self._clear_content()

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text="📋 Relatórios de Scan",
                font=ctk.CTkFont(size=24, weight="bold"),
                text_color=COLORS["text_primary"],
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text="📋 Relatórios de Scan",
                font=("Arial", 24, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["text_primary"],
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        try:
            history = self.db.get_scan_history(limit=20)
            if history:
                for scan in history:
                    risk = scan.get("risk_score", 0) or 0
                    color = COLORS["accent_green"] if risk < 30 else (
                        COLORS["accent_yellow"] if risk < 60 else COLORS["accent_red"]
                    )

                    if CTK_AVAILABLE:
                        entry_frame = ctk.CTkFrame(
                            self.content_frame,
                            fg_color=COLORS["dark_card"],
                            corner_radius=8
                        )
                        entry_frame.pack(fill="x", pady=3, padx=5)

                        ctk.CTkLabel(
                            entry_frame,
                            text=f"{scan.get('scan_type', 'unknown')} | "
                                 f"Risco: {risk:.1f}% | "
                                 f"Ameaças: {scan.get('threat_count', 0)}",
                            font=ctk.CTkFont(size=12),
                            text_color=color,
                            anchor="w"
                        ).pack(fill="x", padx=10, pady=5)

                        ctk.CTkLabel(
                            entry_frame,
                            text=f"Data: {scan.get('timestamp', '')}",
                            font=ctk.CTkFont(size=10),
                            text_color=COLORS["text_muted"],
                            anchor="w"
                        ).pack(fill="x", padx=10, pady=(0, 5))
                    else:
                        tk.Frame(
                            self.content_frame, height=2, bg=COLORS["border"]
                        ).pack(fill="x", pady=3, padx=5)
            else:
                ctk.CTkLabel(
                    self.content_frame,
                    text="Nenhum relatório disponível. Execute um scan primeiro.",
                    font=ctk.CTkFont(size=14),
                    text_color=COLORS["text_muted"]
                ).pack(pady=50)
        except Exception as e:
            ctk.CTkLabel(
                self.content_frame,
                text=f"Erro ao carregar relatórios: {str(e)}",
                font=ctk.CTkFont(size=14),
                text_color=COLORS["accent_red"]
            ).pack(pady=50)

    def _show_settings(self):
        """Exibe configurações."""
        self._clear_content()

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text="⚙️ Configurações",
                font=ctk.CTkFont(size=24, weight="bold"),
                text_color=COLORS["text_primary"],
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text="⚙️ Configurações",
                font=("Arial", 24, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["text_primary"],
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        settings = [
            ("Tamanho máximo de arquivo", "max_file_size_mb", "scanner", "100"),
            ("Profundidade de scan", "scan_depth", "scanner", "10"),
            ("Intervalo de scan automático", "scan_interval_seconds", "scanner", "300"),
            ("Limiar de confiança IA", "confidence_threshold", "ai", "0.7"),
            ("Aprendizado automático", "learning_enabled", "ai", "True"),
        ]

        for label, key, section, default in settings:
            if CTK_AVAILABLE:
                frame = ctk.CTkFrame(
                    self.content_frame, fg_color=COLORS["dark_card"], corner_radius=8
                )
                frame.pack(fill="x", pady=3, padx=5)

                ctk.CTkLabel(
                    frame, text=label, font=ctk.CTkFont(size=12),
                    text_color=COLORS["text_primary"], anchor="w"
                ).pack(side="left", padx=10, pady=8)

                value = self.engine.config.get(section, key, default)
                ctk.CTkLabel(
                    frame, text=str(value), font=ctk.CTkFont(size=12),
                    text_color=COLORS["accent_blue"], anchor="w"
                ).pack(side="right", padx=10, pady=8)

    def _show_threats(self, report):
        """Exibe ameaças detectadas."""
        self._clear_content()

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text="⚠️ Ameaças Detectadas",
                font=ctk.CTkFont(size=24, weight="bold"),
                text_color=COLORS["accent_red"],
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text="⚠️ Ameaças Detectadas",
                font=("Arial", 24, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["accent_red"],
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        if report.threats:
            for threat in report.threats:
                threat_dict = {
                    "threat_type": threat.threat_type,
                    "description": threat.description,
                    "risk_level": threat.risk_level,
                    "probability": threat.probability,
                    "confidence": threat.confidence
                }
                card = ThreatCard(self.content_frame, threat_dict)
                if card.frame:
                    card.frame.pack(fill="x", pady=5, padx=5)
        else:
            ctk.CTkLabel(
                self.content_frame,
                text="✓ Nenhuma ameaça detectada!",
                font=ctk.CTkFont(size=20),
                text_color=COLORS["accent_green"]
            ).pack(pady=50)

    # ========================================================================
    # EXECUÇÃO DE SCANS
    # ========================================================================

    def _run_full_scan(self, target_path: str):
        """Executa scan completo em thread."""
        try:
            self.scan_log.add_entry(f"Iniciando scan em: {target_path}", "info")

            def progress_callback(files_done, total_files, current_file):
                if self.scan_progress and CTK_AVAILABLE:
                    progress = min(1.0, files_done / max(total_files, 1))
                    self.root.after(0, lambda: self.scan_progress.set(progress))
                self.scan_log.add_entry(
                    f"Verificando: {current_file}", "info"
                )

            report = self.engine.full_scan(target_path, progress_callback)

            # Mostrar resultados
            self.root.after(0, lambda: self._display_scan_results(report))

        except Exception as e:
            self.scan_log.add_entry(f"Erro no scan: {str(e)}", "critical")
        finally:
            self._scan_in_progress = False

    def _run_quick_scan(self):
        """Executa scan rápido em thread."""
        try:
            self.activity_log.add_entry("Iniciando scan rápido...", "info")
            report = self.engine.quick_scan()
            self.root.after(0, lambda: self._display_scan_results(report))
        except Exception as e:
            self.activity_log.add_entry(f"Erro no scan rápido: {str(e)}", "critical")
        finally:
            self._scan_in_progress = False

    def _display_scan_results(self, report):
        """Exibe resultados do scan."""
        self._clear_content()

        risk = report.overall_risk_score
        risk_color = COLORS["accent_green"] if risk < 30 else (
            COLORS["accent_yellow"] if risk < 60 else COLORS["accent_red"]
        )

        if CTK_AVAILABLE:
            header = ctk.CTkLabel(
                self.content_frame,
                text=f"Scan Concluído - Risco: {risk:.1f}%",
                font=ctk.CTkFont(size=20, weight="bold"),
                text_color=risk_color,
                anchor="w"
            )
        else:
            header = tk.Label(
                self.content_frame,
                text=f"Scan Concluído - Risco: {risk:.1f}%",
                font=("Arial", 20, "bold"),
                bg=COLORS["dark_bg"],
                fg=risk_color,
                anchor="w"
            )
        header.pack(fill="x", pady=(0, 15))

        # Resumo
        summary_text = report.summary
        summary_label = ctk.CTkLabel(
            self.content_frame,
            text=summary_text,
            font=ctk.CTkFont(size=14),
            text_color=COLORS["text_primary"],
            anchor="w",
            wraplength=600
        ) if CTK_AVAILABLE else tk.Label(
            self.content_frame,
            text=summary_text,
            font=("Arial", 14),
            bg=COLORS["dark_bg"],
            fg=COLORS["text_primary"],
            anchor="w",
            wraplength=600
        )
        summary_label.pack(fill="x", pady=(0, 10))

        # Ações recomendadas
        if report.immediate_actions:
            action_header = ctk.CTkLabel(
                self.content_frame,
                text="Ações Imediatas:",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COLORS["accent_red"],
                anchor="w"
            ) if CTK_AVAILABLE else tk.Label(
                self.content_frame,
                text="Ações Imediatas:",
                font=("Arial", 14, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["accent_red"],
                anchor="w"
            )
            action_header.pack(fill="x", pady=(10, 5))

            for action in report.immediate_actions:
                ctk.CTkLabel(
                    self.content_frame,
                    text=f"  ⚡ {action}",
                    font=ctk.CTkFont(size=12),
                    text_color=COLORS["accent_red"],
                    anchor="w"
                ).pack(fill="x", padx=20)

        if report.short_term_actions:
            action_header = ctk.CTkLabel(
                self.content_frame,
                text="Ações Recomendadas:",
                font=ctk.CTkFont(size=14, weight="bold"),
                text_color=COLORS["accent_yellow"],
                anchor="w"
            ) if CTK_AVAILABLE else tk.Label(
                self.content_frame,
                text="Ações Recomendadas:",
                font=("Arial", 14, "bold"),
                bg=COLORS["dark_bg"],
                fg=COLORS["accent_yellow"],
                anchor="w"
            )
            action_header.pack(fill="x", pady=(10, 5))

            for action in report.short_term_actions:
                ctk.CTkLabel(
                    self.content_frame,
                    text=f"  ⚠ {action}",
                    font=ctk.CTkFont(size=12),
                    text_color=COLORS["accent_yellow"],
                    anchor="w"
                ).pack(fill="x", padx=20)

        # Ameaças
        threat_header = ctk.CTkLabel(
            self.content_frame,
            text=f"Ameaças Detectadas: {report.threat_count}",
            font=ctk.CTkFont(size=16, weight="bold"),
            text_color=COLORS["text_primary"],
            anchor="w"
        ) if CTK_AVAILABLE else tk.Label(
            self.content_frame,
            text=f"Ameaças Detectadas: {report.threat_count}",
            font=("Arial", 16, "bold"),
            bg=COLORS["dark_bg"],
            fg=COLORS["text_primary"],
            anchor="w"
        )
        threat_header.pack(fill="x", pady=(15, 5))

        if report.threats:
            for threat in report.threats:
                threat_dict = {
                    "threat_type": threat.threat_type,
                    "description": threat.description,
                    "risk_level": threat.risk_level,
                    "probability": threat.probability,
                    "confidence": threat.confidence
                }
                card = ThreatCard(self.content_frame, threat_dict)
                if card.frame:
                    card.frame.pack(fill="x", pady=3, padx=5)
        else:
            ctk.CTkLabel(
                self.content_frame,
                text="✓ Nenhuma ameaça detectada! Sistema limpo.",
                font=ctk.CTkFont(size=16),
                text_color=COLORS["accent_green"]
            ).pack(pady=20)

        # Atualizar status
        self._update_status_bar(
            f"Scan concluído | Risco: {risk:.1f}% | "
            f"Ameaças: {report.threat_count} | {datetime.now().strftime('%H:%M:%S')}"
        )

    # ========================================================================
    # CALLBACKS
    # ========================================================================

    def _on_scan_started(self, data: Dict):
        self.activity_log.add_entry(f"Scan iniciado: {data.get('type', 'unknown')}", "info")

    def _on_scan_completed(self, data: Dict):
        risk = data.get("risk_score", 0)
        self.activity_log.add_entry(
            f"Scan concluído - Risco: {risk:.1f}%", "info"
        )

    def _on_network_alert(self, data: Dict):
        severity = data.get("severity", "info")
        self.activity_log.add_entry(
            f"Alerta de rede [{severity}]: {data.get('message', '')}", severity
        )

    def _on_process_alert(self, data: Dict):
        name = data.get("name", "unknown")
        suspicious = data.get("suspicious", False)
        level = "warning" if suspicious else "info"
        self.activity_log.add_entry(
            f"Processo detectado: {name} (PID: {data.get('pid', '?')})"
            f" {'[SUSPEITO]' if suspicious else ''}", level
        )

    # ========================================================================
    # UTILITÁRIOS
    # ========================================================================

    def _clear_content(self):
        """Limpa o conteúdo principal."""
        for widget in self.content_frame.winfo_children():
            widget.destroy()

    def _update_status_bar(self, text: str):
        """Atualiza a barra de status."""
        try:
            self.status_label.configure(text=f" {text}")
        except Exception:
            pass

    def run(self):
        """Inicia a aplicação."""
        self.root.mainloop()
