"""Módulo de Interface Gráfica."""
from .app import SentinelApp
__all__ = ['SentinelApp']
