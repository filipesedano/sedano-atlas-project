#!/usr/bin/env python3
"""
Sentinel AI - Sistema de Segurança Inteligente
Ponto de entrada principal do sistema.
"""

import os
import sys
import argparse
import logging
import json
from datetime import datetime

# Adicionar diretório raiz ao path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# Tentar import direto
try:
    from sentinel_ai.config import config as _config
except ImportError:
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from sentinel_ai.config import config
from sentinel_ai.core.engine import SentinelEngine, dataclass_to_dict
from sentinel_ai.database.db_manager import DatabaseManager
from sentinel_ai.crypto.crypto_manager import CryptoManager


def setup_logging(level=logging.INFO):
    """Configura o sistema de logging."""
    logging.basicConfig(
        level=level,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.StreamHandler(sys.stdout),
        ]
    )
    # Logger do Sentinel
    sentinel_logger = logging.getLogger("sentinel")
    sentinel_logger.setLevel(level)
    return sentinel_logger


def run_cli_scan(engine, target_path="/"):
    """Executa scan via CLI."""
    print(f"\n{'='*60}")
    print(f"  SENTINEL AI - Scan Completo")
    print(f"  Alvo: {target_path}")
    print(f"  Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")

    print("[1/4] Scanner de Arquivos...")
    file_report = engine.file_agent.full_scan(target_path)
    print(f"   → {file_report.total_files_scanned} arquivos escaneados")
    print(f"   → {file_report.suspicious_files} arquivos suspeitos")
    print(f"   → {len(file_report.altered_files)} arquivos alterados")
    print(f"   → {len(file_report.encryption_suspicion)} indicadores de criptografia")

    print("\n[2/4] Scanner de Rede...")
    network_report = engine.network_agent.full_scan()
    print(f"   → {network_report.total_connections} conexões ativas")
    print(f"   → {network_report.suspicious_connections} conexões suspeitas")
    print(f"   → {network_report.active_alerts} alertas de rede")

    print("\n[3/4] Scanner de Processos...")
    process_report = engine.process_agent.full_scan()
    print(f"   → {process_report.total_processes} processos ativos")
    print(f"   → {process_report.suspicious_processes} processos suspeitos")
    print(f"   → {len(process_report.resource_anomalies)} anomalias de recursos")

    print("\n[4/4] Análise de Logs...")
    log_report = engine.log_agent.scan_system_logs()
    print(f"   → {log_report.total_events_analyzed} eventos analisados")
    print(f"   → {log_report.suspicious_events} eventos suspeitos")
    print(f"   → {len(log_report.patterns_detected)} padrões detectados")

    # Análise da IA
    print("\n[IA] Analisando resultados...")
    comprehensive = engine.ai_agent.analyze_all_data(
        file_report=dataclass_to_dict(file_report),
        network_report=dataclass_to_dict(network_report),
        log_report=dataclass_to_dict(log_report),
        process_report=dataclass_to_dict(process_report)
    )

    # Exibir resultado
    print(f"\n{'='*60}")
    print(f"  RESULTADO FINAL")
    print(f"{'='*60}")
    print(f"\n  Risco Geral: {comprehensive.overall_risk_score:.1f}%")
    print(f"  Ameaças Detectadas: {comprehensive.threat_count}")
    print(f"\n  Resumo: {comprehensive.summary}")

    if comprehensive.threats:
        print(f"\n  AMEAÇAS:")
        for threat in comprehensive.threats:
            print(f"    • {threat.threat_type}: {threat.probability:.1f}% "
                  f"(confiança: {threat.confidence:.1f}%)")
            print(f"      Descrição: {threat.description}")

    if comprehensive.immediate_actions:
        print(f"\n  AÇÕES IMEDIATAS:")
        for action in comprehensive.immediate_actions:
            print(f"    ⚡ {action}")

    if comprehensive.short_term_actions:
        print(f"\n  AÇÕES RECOMENDADAS:")
        for action in comprehensive.short_term_actions:
            print(f"    ⚠ {action}")

    print(f"\n{'='*60}\n")
    return comprehensive


def run_quick_scan_cli(engine):
    """Executa scan rápido via CLI."""
    print(f"\n{'='*60}")
    print(f"  SENTINEL AI - Scan Rápido")
    print(f"  Data: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"{'='*60}\n")

    file_report = engine.file_agent.quick_scan()
    network_report = engine.network_agent.full_scan()
    process_report = engine.process_agent.full_scan()

    comprehensive = engine.ai_agent.analyze_all_data(
        file_report=dataclass_to_dict(file_report),
        network_report=dataclass_to_dict(network_report),
        process_report=dataclass_to_dict(process_report)
    )

    print(f"  Risco Geral: {comprehensive.overall_risk_score:.1f}%")
    print(f"  Ameaças: {comprehensive.threat_count}")
    print(f"  Resumo: {comprehensive.summary}")

    if comprehensive.threats:
        for threat in comprehensive.threats:
            print(f"    • {threat.threat_type}: {threat.probability:.1f}%")

    print(f"\n{'='*60}\n")
    return comprehensive


def run_monitoring(engine):
    """Executa monitoramento contínuo via CLI."""
    print(f"\n{'='*60}")
    print(f"  SENTINEL AI - Monitoramento em Tempo Real")
    print(f"  Pressione Ctrl+C para parar")
    print(f"{'='*60}\n")

    engine.start_real_time_monitoring()

    try:
        while True:
            status = engine.get_status()
            print(f"\r[{status.uptime:.0f}s] "
                  f"Tarefa: {status.current_task} | "
                  f"Risco: {status.system_risk_score:.1f}% | "
                  f"Scans: {status.scans_completed} | "
                  f"Ameaças: {status.threats_detected}",
                  end="", flush=True)
            __import__('time').sleep(5)
    except KeyboardInterrupt:
        print("\n\nParando monitoramento...")
        engine.stop_real_time_monitoring()
        print("Monitoramento parado.")


def show_status(engine):
    """Exibe status do sistema."""
    status = engine.get_status()
    stats = engine.db.get_statistics()

    print(f"\n{'='*60}")
    print(f"  SENTINEL AI - Status do Sistema")
    print(f"{'='*60}")
    print(f"\n  Engine: {'Rodando' if status.is_running else 'Parado'}")
    print(f"  Tarefa atual: {status.current_task}")
    print(f"  Risco atual: {status.system_risk_score:.1f}%")
    print(f"  Scans completados: {status.scans_completed}")
    print(f"  Ameaças detectadas: {status.threats_detected}")
    print(f"  Uptime: {status.uptime:.0f}s")
    print(f"\n  Banco de dados:")
    print(f"    Total de scans: {stats.get('total_scans', 0)}")
    print(f"    Alertas críticos: {stats.get('critical_alerts', 0)}")
    print(f"    Risco médio: {stats.get('average_risk_score', 0):.1f}%")
    print(f"\n{'='*60}\n")


def show_config(engine):
    """Exibe configuração atual."""
    all_config = engine.config.all_config
    print(f"\n{'='*60}")
    print(f"  SENTINEL AI - Configuração")
    print(f"{'='*60}\n")

    for section, values in all_config.items():
        print(f"  [{section}]")
        for key, value in values.items():
            if isinstance(value, list):
                value_str = f"[{', '.join(str(v) for v in value[:5])}...]"
                if len(value) <= 5:
                    value_str = f"[{', '.join(str(v) for v in value)}]"
            else:
                value_str = str(value)
            print(f"    {key} = {value_str}")
        print()

    print(f"{'='*60}\n")


def main():
    """Função principal."""
    parser = argparse.ArgumentParser(
        description="Sentinel AI - Sistema de Segurança Inteligente",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos:
  python main.py                    Iniciar interface gráfica
  python main.py --cli scan /home   Scan completo via CLI
  python main.py --cli quick        Scan rápido via CLI
  python main.py --cli monitor      Monitoramento em tempo real
  python main.py --cli status       Status do sistema
  python main.py --cli config       Mostrar configuração
        """
    )

    parser.add_argument("--cli", action="store_true",
                       help="Usar interface de linha de comando")
    parser.add_argument("--gui", action="store_true",
                       help="Usar interface gráfica (padrão)")
    parser.add_argument("--target", type=str, default="/",
                       help="Diretório alvo para scan")
    parser.add_argument("--level", type=str, default="INFO",
                       choices=["DEBUG", "INFO", "WARNING", "ERROR"],
                       help="Nível de log")
    parser.add_argument("command", nargs="?", choices=["scan", "quick", "monitor", "status", "config"],
                       default="gui", help="Comando CLI")

    args = parser.parse_args()

    # Configurar logging
    logger = setup_logging(getattr(logging, args.level))
    logger.info("Sentinel AI inicializando...")

    # Inicializar engine
    engine = SentinelEngine()
    engine.initialize()

    # Criptografia
    crypto = CryptoManager()
    crypto.ensure_key_exists()
    logger.info("Criptografia configurada")

    if args.cli or args.command != "gui":
        # Modo CLI
        cmd = args.command

        if cmd == "scan":
            run_cli_scan(engine, args.target)
        elif cmd == "quick":
            run_quick_scan_cli(engine)
        elif cmd == "monitor":
            run_monitoring(engine)
        elif cmd == "status":
            show_status(engine)
        elif cmd == "config":
            show_config(engine)
        else:
            # Sem comando, mostrar ajuda
            parser.print_help()
    else:
        # Modo GUI
        logger.info("Iniciando interface gráfica...")
        try:
            from sentinel_ai.ui.app import SentinelApp
            app = SentinelApp()
            app.engine = engine
            app.crypto = crypto
            app.run()
        except ImportError as e:
            logger.error(f"Erro ao iniciar GUI: {e}")
            print("\nCustomTkinter não instalado. Usando modo CLI.")
            print("Instale com: pip install customtkinter")
            run_quick_scan_cli(engine)


if __name__ == "__main__":
    main()
