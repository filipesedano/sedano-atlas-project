"""
Módulo Agents - Agentes especializados do Sentinel AI.
"""

from .file_agent import FileAgent, FileAgentReport
from .network_agent import NetworkAgent, NetworkAgentReport
from .log_agent import LogAgent, LogAgentReport
from .ai_agent import AIAgent, ThreatAnalysis, ComprehensiveReport
from .process_agent import ProcessAgent, ProcessAgentReport

__all__ = [
    'FileAgent', 'FileAgentReport',
    'NetworkAgent', 'NetworkAgentReport',
    'LogAgent', 'LogAgentReport',
    'AIAgent', 'ThreatAnalysis', 'ComprehensiveReport',
    'ProcessAgent', 'ProcessAgentReport',
]
