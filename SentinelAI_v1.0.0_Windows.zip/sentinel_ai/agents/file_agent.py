"""
Agente de Arquivos.
Responsável por: verificar arquivos, identificar alterações,
detectar criptografia suspeita, analisar comportamento de arquivos.
"""

import os
import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

from ..scanner.file_scanner import FileScanner, FileScanResult
from ..database.db_manager import DatabaseManager

logger = logging.getLogger("sentinel.agent.file")


@dataclass
class FileAgentReport:
    """Relatório do Agente de Arquivos."""
    total_files_scanned: int
    suspicious_files: int
    critical_files: int
    altered_files: List[Dict]
    encryption_suspicion: List[Dict]
    risk_score: float  # 0-100
    summary: str
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.now)


class FileAgent:
    """Agente especializado em análise de arquivos."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.scanner = FileScanner()
        self.db = db_manager
        self._scan_history: List[FileScanResult] = []
        self._report_count = 0

    def full_scan(self, target_path: str = "/", progress_callback=None) -> FileAgentReport:
        """Realiza scan completo de arquivos."""
        logger.info(f"Iniciando scan completo: {target_path}")

        dir_result = self.scanner.scan_directory(target_path, progress_callback)
        if not dir_result:
            return FileAgentReport(
                total_files_scanned=0,
                suspicious_files=0,
                critical_files=0,
                altered_files=[],
                encryption_suspicion=[],
                risk_score=0,
                summary="Scan não pôde ser completado",
                recommendations=["Verifique as permissões do diretório"]
            )

        # Detectar arquivos alterados
        altered = self.scanner.detect_altered_files(target_path)

        # Detectar criptografia suspeita
        encryption = self.scanner.detect_encryption_suspicion(target_path)

        # Calcular score de risco
        risk_score = self._calculate_risk_score(dir_result, altered, encryption)

        # Gerar resumo e recomendações
        summary = self._generate_summary(dir_result, altered, encryption)
        recommendations = self._generate_recommendations(dir_result, altered, encryption)

        report = FileAgentReport(
            total_files_scanned=dir_result.files_scanned,
            suspicious_files=dir_result.suspicious_files,
            critical_files=sum(1 for r in dir_result.results
                             if r.risk_level in ["critical", "high"]),
            altered_files=altered,
            encryption_suspicion=encryption,
            risk_score=risk_score,
            summary=summary,
            recommendations=recommendations
        )

        # Salvar no banco de dados
        if self.db:
            self.db.save_scan_result("file_scan", report)

        # Atualizar baseline
        for result in dir_result.results:
            self.scanner.set_base_hashes({result.path: result.hash_value})

        self._report_count += 1
        self._scan_history.extend(dir_result.results)

        logger.info(f"Scan completo. Risco: {risk_score:.1f}%, "
                     f"Suspeitos: {dir_result.suspicious_files}")
        return report

    def quick_scan(self, paths: List[str] = None) -> FileAgentReport:
        """Scan rápido de diretórios comuns."""
        if not paths:
            paths = [
                os.path.expanduser("~"),
                "/tmp",
                "/var/tmp",
            ]

        all_results = []
        for path in paths:
            if os.path.exists(path):
                if os.path.isfile(path):
                    result = self.scanner.scan_file(path)
                    if result:
                        all_results.append(result)
                elif os.path.isdir(path):
                    dir_result = self.scanner.scan_directory(path)
                    if dir_result:
                        all_results.extend(dir_result.results)

        suspicious = sum(1 for r in all_results if r.is_suspicious)
        risk_score = min(100, (suspicious / max(len(all_results), 1)) * 100 * 2)

        return FileAgentReport(
            total_files_scanned=len(all_results),
            suspicious_files=suspicious,
            critical_files=sum(1 for r in all_results if r.risk_level in ["critical", "high"]),
            altered_files=[],
            encryption_suspicion=[],
            risk_score=risk_score,
            summary=f"Quick scan: {len(all_results)} arquivos, {suspicious} suspeitos",
            recommendations=[
                "Execute um scan completo para análise mais detalhada"
            ] if suspicious > 0 else ["Sistema aparentemente limpo"]
        )

    def _calculate_risk_score(self, dir_result, altered, encryption) -> float:
        """Calcula score de risco geral."""
        if dir_result.total_files == 0:
            return 0

        # Componentes do score
        suspicious_ratio = dir_result.suspicious_files / max(dir_result.total_files, 1)
        altered_count = len(altered)
        encryption_count = len(encryption)

        # Pesos
        score = (
            suspicious_ratio * 40 +        # 40% peso para arquivos suspeitos
            min(altered_count * 10, 30) +   # 30% para arquivos alterados
            min(encryption_count * 15, 30)  # 30% para criptografia suspeita
        )

        return min(100, score)

    def _generate_summary(self, dir_result, altered, encryption) -> str:
        """Gera resumo do scan."""
        parts = [
            f"Scan concluído em {dir_result.scan_duration:.1f}s",
            f"{dir_result.files_scanned} arquivos escaneados",
        ]

        if dir_result.suspicious_files > 0:
            parts.append(f"{dir_result.suspicious_files} arquivos suspeitos encontrados")

        if altered:
            parts.append(f"{len(altered)} arquivos alterados desde o último scan")

        if encryption:
            parts.append(f"{len(encryption)} indicadores de criptografia suspeita")

        return "; ".join(parts)

    def _generate_recommendations(self, dir_result, altered, encryption) -> List[str]:
        """Gera recomendações baseadas nos resultados."""
        recommendations = []

        if dir_result.suspicious_files > 0:
            recommendations.append(
                "Revise os arquivos suspeitos encontrados"
            )

        if altered:
            recommendations.append(
                "Verifique as alterações nos arquivos - podem ser legítimas ou maliciosas"
            )

        if encryption:
            recommendations.append(
                "ALERTA: Possível atividade de ransomware! Desconecte da rede imediatamente"
            )

        if not recommendations:
            recommendations.append("Continue monitorando regularmente")

        return recommendations

    def get_report_history(self) -> List[Dict]:
        """Retorna histórico de relatórios."""
        if self.db:
            return self.db.get_scan_history("file_scan")
        return []

    @property
    def scan_count(self) -> int:
        return self._report_count
