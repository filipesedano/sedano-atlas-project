"""
Agente de Logs.
Responsável por: analisar eventos do sistema, procurar padrões,
correlacionar horários, detectar atividades suspeitas em logs.
"""

import os
import re
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from collections import defaultdict

from ..config import config
from ..database.db_manager import DatabaseManager

logger = logging.getLogger("sentinel.agent.log")


@dataclass
class LogEvent:
    """Evento de log analisado."""
    timestamp: str
    source: str
    event_type: str
    severity: str
    message: str
    details: Dict = field(default_factory=dict)


@dataclass
class LogPattern:
    """Padrão detectado em logs."""
    pattern_name: str
    occurrences: int
    time_window: str
    severity: str
    description: str
    related_events: List[LogEvent] = field(default_factory=list)


@dataclass
class LogAgentReport:
    """Relatório do Agente de Logs."""
    total_events_analyzed: int
    suspicious_events: int
    patterns_detected: List[LogPattern]
    correlations: List[Dict]
    risk_score: float
    summary: str
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.now)


class LogAgent:
    """Agente especializado em análise de logs."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.config = config
        self.db = db_manager
        self._suspicious_patterns = self._load_patterns()
        self._log_cache: List[LogEvent] = []
        self._event_count = 0

    def _load_patterns(self) -> List[Dict]:
        """Carrega padrões suspeitos para busca em logs."""
        return [
            {
                "name": "failed_login",
                "regex": r"(failed|failure|invalid|unauthorized|denied).*(login|auth|password)",
                "severity": "medium",
                "description": "Tentativas de login falhadas"
            },
            {
                "name": "sudo_abuse",
                "regex": r"(sudo|su\s).*(failed|incorrect|wrong)",
                "severity": "high",
                "description": "Possível abuso de privilégios"
            },
            {
                "name": "privilege_escalation",
                "regex": r"(privilege|escalat|root|admin).*(gained|obtained|elevated)",
                "severity": "critical",
                "description": "Possível elevação de privilégios"
            },
            {
                "name": "file_access_suspicious",
                "regex": r"(access.*denied|permission|forbidden).*(passwd|shadow|sudoers)",
                "severity": "high",
                "description": "Acesso não autorizado a arquivos críticos"
            },
            {
                "name": "network_anomaly",
                "regex": r"(connection.*refused|port.*scan|firewall.*block|iptables.*drop)",
                "severity": "medium",
                "description": "Anomalias de rede detectadas"
            },
            {
                "name": "malware_indicator",
                "regex": r"(malware|trojan|virus|ransomware|backdoor|rootkit)",
                "severity": "critical",
                "description": "Indicadores de malware em logs"
            },
            {
                "name": "suspicious_process",
                "regex": r"(kill.*signal|segfault|core.*dump|abnormal.*termination)",
                "severity": "medium",
                "description": "Processos terminando anormalmente"
            },
            {
                "name": "crypto_activity",
                "regex": r"(cryptographic|encryption|decrypt|key.*exchange)",
                "severity": "low",
                "description": "Atividade criptográfica detectada"
            },
            {
                "name": "brute_force",
                "regex": r"(multiple.*failed|repeated.*attempt|too.*many.*authentication)",
                "severity": "high",
                "description": "Possível ataque de força bruta"
            },
            {
                "name": "data_exfiltration",
                "regex": r"(large.*transfer|upload.*unusual|outbound.*connection.*suspicious)",
                "severity": "critical",
                "description": "Possível exfiltração de dados"
            }
        ]

    def scan_system_logs(self) -> LogAgentReport:
        """Analisa logs do sistema."""
        logger.info("Iniciando análise de logs do sistema")

        events = []

        # Analisar syslog/journalctl
        events.extend(self._scan_syslog())

        # Analisar auth logs
        events.extend(self._scan_auth_logs())

        # Analisar kernel logs
        events.extend(self._scan_kernel_logs())

        # Analisar cron logs
        events.extend(self._scan_cron_logs())

        # Detectar padrões
        patterns = self._detect_patterns(events)

        # Correlacionar eventos
        correlations = self._correlate_events(events)

        # Calcular risco
        risk_score = self._calculate_risk(events, patterns)

        # Gerar relatório
        suspicious = sum(1 for e in events if e.severity in ["high", "critical"])
        report = LogAgentReport(
            total_events_analyzed=len(events),
            suspicious_events=suspicious,
            patterns_detected=patterns,
            correlations=correlations,
            risk_score=risk_score,
            summary=self._generate_summary(events, patterns),
            recommendations=self._generate_recommendations(patterns, correlations)
        )

        self._event_count += len(events)
        if self.db:
            self.db.save_scan_result("log_analysis", report)

        logger.info(f"Análise de logs concluída: {len(events)} eventos, "
                     f"{len(patterns)} padrões, risco: {risk_score:.1f}%")
        return report

    def _scan_syslog(self) -> List[LogEvent]:
        """Analisa syslog."""
        events = []
        log_files = ['/var/log/syslog', '/var/log/messages']

        for log_file in log_files:
            if not os.path.isfile(log_file):
                continue
            try:
                with open(log_file, 'r', errors='replace') as f:
                    lines = f.readlines()[-1000:]  # Últimas 1000 linhas

                for line in lines:
                    event = self._parse_syslog_line(line, "syslog")
                    if event:
                        events.append(event)
            except (IOError, PermissionError):
                pass

        return events

    def _scan_auth_logs(self) -> List[LogEvent]:
        """Analisa logs de autenticação."""
        events = []
        auth_files = ['/var/log/auth.log', '/var/log/secure', '/var/log/btmp']

        for log_file in auth_files:
            if not os.path.isfile(log_file):
                continue
            try:
                with open(log_file, 'r', errors='replace') as f:
                    lines = f.readlines()[-500:]

                for line in lines:
                    event = self._parse_auth_line(line)
                    if event:
                        events.append(event)
            except (IOError, PermissionError):
                pass

        return events

    def _scan_kernel_logs(self) -> List[LogEvent]:
        """Analisa logs do kernel."""
        events = []
        try:
            # Tentar usar dmesg
            import subprocess
            result = subprocess.run(['dmesg', '--level=err,warn'],
                                  capture_output=True, text=True, timeout=5)
            if result.returncode == 0:
                for line in result.stdout.split('\n')[-200:]:
                    if line.strip():
                        events.append(LogEvent(
                            timestamp=str(datetime.now()),
                            source="kernel",
                            event_type="kernel_warning",
                            severity="low",
                            message=line.strip()[:200]
                        ))
        except (FileNotFoundError, subprocess.TimeoutExpired):
            # Fallback: ler kmsg
            try:
                with open('/proc/kmsg', 'r') as f:
                    for line in f:
                        if 'error' in line.lower() or 'warning' in line.lower():
                            events.append(LogEvent(
                                timestamp=str(datetime.now()),
                                source="kernel",
                                event_type="kernel_message",
                                severity="low",
                                message=line.strip()[:200]
                            ))
                        if len(events) > 100:
                            break
            except (IOError, PermissionError):
                pass

        return events

    def _scan_cron_logs(self) -> List[LogEvent]:
        """Analisa logs do cron."""
        events = []
        try:
            with open('/var/log/cron.log', 'r', errors='replace') as f:
                lines = f.readlines()[-100:]
            for line in lines:
                if 'error' in line.lower() or 'fail' in line.lower():
                    events.append(LogEvent(
                        timestamp=str(datetime.now()),
                        source="cron",
                        event_type="cron_error",
                        severity="medium",
                        message=line.strip()[:200]
                    ))
        except (IOError, PermissionError):
            pass

        return events

    def _parse_syslog_line(self, line: str, source: str) -> Optional[LogEvent]:
        """Parseia uma linha de syslog."""
        if not line.strip():
            return None

        severity = "low"
        event_type = "info"

        line_lower = line.lower()

        # Classificar por severidade
        if any(kw in line_lower for kw in ['error', 'fail', 'critical', 'fatal']):
            severity = "high"
            event_type = "error"
        elif any(kw in line_lower for kw in ['warning', 'warn']):
            severity = "medium"
            event_type = "warning"
        elif any(kw in line_lower for kw in ['emergency', 'emerg', 'panic']):
            severity = "critical"
            event_type = "emergency"

        # Extrair timestamp
        timestamp = ""
        match = re.match(r'(\w{3}\s+\d+\s+\d+:\d+:\d+)', line)
        if match:
            timestamp = match.group(1)

        return LogEvent(
            timestamp=timestamp,
            source=source,
            event_type=event_type,
            severity=severity,
            message=line.strip()[:300]
        )

    def _parse_auth_line(self, line: str) -> Optional[LogEvent]:
        """Parseia uma linha de log de autenticação."""
        if not line.strip():
            return None

        severity = "medium"
        event_type = "auth_event"
        line_lower = line.lower()

        if 'failed' in line_lower or 'failure' in line_lower:
            severity = "high"
            event_type = "auth_failure"
        elif 'accepted' in line_lower or 'success' in line_lower:
            severity = "low"
            event_type = "auth_success"

        timestamp = ""
        match = re.match(r'(\w{3}\s+\d+\s+\d+:\d+:\d+)', line)
        if match:
            timestamp = match.group(1)

        return LogEvent(
            timestamp=timestamp,
            source="auth",
            event_type=event_type,
            severity=severity,
            message=line.strip()[:300]
        )

    def _detect_patterns(self, events: List[LogEvent]) -> List[LogPattern]:
        """Detecta padrões nos eventos."""
        patterns = []

        for pattern_def in self._suspicious_patterns:
            matches = []
            regex = re.compile(pattern_def["regex"], re.IGNORECASE)

            for event in events:
                if regex.search(event.message):
                    matches.append(event)

            if matches:
                patterns.append(LogPattern(
                    pattern_name=pattern_def["name"],
                    occurrences=len(matches),
                    time_window="recent",
                    severity=pattern_def["severity"],
                    description=pattern_def["description"],
                    related_events=matches[:5]  # Limitar eventos
                ))

        return patterns

    def _correlate_events(self, events: List[LogEvent]) -> List[Dict]:
        """Correlaciona eventos para encontrar relações."""
        correlations = []

        # Agrupar por tipo
        by_type = defaultdict(list)
        for event in events:
            by_type[event.event_type].append(event)

        # Verificar múltiplas tentativas de login (brute force)
        auth_failures = by_type.get("auth_failure", [])
        if len(auth_failures) > 5:
            correlations.append({
                "type": "brute_force_attempt",
                "severity": "high",
                "message": f"{len(auth_failures)} tentativas de autenticação falhadas",
                "events_count": len(auth_failures)
            })

        # Verificar erros seguidos de sucesso (possível invasão)
        if auth_failures and by_type.get("auth_success"):
            correlations.append({
                "type": "failed_then_success",
                "severity": "high",
                "message": "Falhas de autenticação seguidas de sucesso",
                "events_count": len(auth_failures) + len(by_type["auth_success"])
            })

        # Verificar erros de sistema após atividade de rede
        network_errors = by_type.get("network_error", [])
        system_errors = by_type.get("error", [])
        if network_errors and system_errors:
            correlations.append({
                "type": "network_system_correlation",
                "severity": "medium",
                "message": "Erros de rede correlacionados com erros do sistema",
                "events_count": len(network_errors) + len(system_errors)
            })

        return correlations

    def _calculate_risk(self, events: List[LogEvent], patterns: List[LogPattern]) -> float:
        """Calcula score de risco."""
        if not events:
            return 0

        severity_scores = {"critical": 40, "high": 25, "medium": 10, "low": 2}

        event_score = sum(severity_scores.get(e.severity, 2) for e in events)
        pattern_score = sum(severity_scores.get(p.severity, 5) for p in patterns)

        total = event_score + pattern_score
        return min(100, total / max(len(events), 1) * 2)

    def _generate_summary(self, events: List[LogEvent], patterns: List[LogPattern]) -> str:
        """Gera resumo."""
        parts = [f"{len(events)} eventos analisados"]

        if patterns:
            parts.append(f"{len(patterns)} padrões suspeitos detectados")

        critical = sum(1 for e in events if e.severity == "critical")
        high = sum(1 for e in events if e.severity == "high")
        if critical or high:
            parts.append(f"{critical} críticos, {high} altos")

        return "; ".join(parts)

    def _generate_recommendations(self, patterns: List[LogPattern],
                                   correlations: List[Dict]) -> List[str]:
        """Gera recomendações."""
        recommendations = []

        for pattern in patterns:
            if pattern.severity == "critical":
                recommendations.append(f"URGENTE: {pattern.description}")
            elif pattern.severity == "high":
                recommendations.append(f"Atenção: {pattern.description}")

        for correlation in correlations:
            if correlation["severity"] == "high":
                recommendations.append(f"Correlação detectada: {correlation['message']}")

        if not recommendations:
            recommendations.append("Logs dentro do padrão normal")

        return recommendations

    def get_event_history(self) -> List[Dict]:
        """Retorna histórico de eventos."""
        if self.db:
            return self.db.get_scan_history("log_analysis")
        return []

    @property
    def event_count(self) -> int:
        return self._event_count
