"""
Agente de Processos.
Responsável por: monitorar processos, detectar comportamento anormal,
verificar uso de recursos, identificar processos suspeitos.
"""

import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime

from ..scanner.process_scanner import ProcessScanner, ProcessInfo, SystemAlert
from ..database.db_manager import DatabaseManager

logger = logging.getLogger("sentinel.agent.process")


@dataclass
class ProcessAgentReport:
    """Relatório do Agente de Processos."""
    total_processes: int
    suspicious_processes: int
    high_risk_processes: int
    resource_anomalies: List[Dict]
    new_processes: List[Dict]
    zombie_processes: int
    risk_score: float
    summary: str
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.now)


class ProcessAgent:
    """Agente especializado em análise de processos."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.scanner = ProcessScanner()
        self.db = db_manager
        self._scan_count = 0
        self._baseline_cpu: Dict[int, float] = {}
        self._baseline_memory: Dict[int, float] = {}

    def full_scan(self) -> ProcessAgentReport:
        """Realiza scan completo de processos."""
        logger.info("Iniciando scan completo de processos")

        result = self.scanner.scan_processes()

        # Verificar integridade do sistema
        system_alerts = self.scanner.check_system_integrity()

        # Detectar anomalias de recursos
        anomalies = self._detect_resource_anomalies(result.processes)

        # Detectar novos processos
        new_procs = self._detect_new_processes(result.processes)

        # Calcular risco
        risk_score = self._calculate_risk(result, anomalies)

        report = ProcessAgentReport(
            total_processes=result.total_processes,
            suspicious_processes=result.suspicious_processes,
            high_risk_processes=sum(
                1 for p in result.processes if p.risk_level in ["critical", "high"]
            ),
            resource_anomalies=anomalies,
            new_processes=new_procs,
            zombie_processes=0,
            risk_score=risk_score,
            summary=f"{result.total_processes} processos, "
                    f"{result.suspicious_processes} suspeitos, "
                    f"{len(anomalies)} anomalias de recursos",
            recommendations=self._generate_recommendations(result, anomalies)
        )

        # Atualizar baseline
        for proc in result.processes:
            self._baseline_cpu[proc.pid] = proc.cpu_percent
            self._baseline_memory[proc.pid] = proc.memory_percent

        if self.db:
            self.db.save_scan_result("process_scan", report)

        self._scan_count += 1
        logger.info(f"Scan de processos concluído. Risco: {risk_score:.1f}%")
        return report

    def _detect_resource_anomalies(self, processes: List[ProcessInfo]) -> List[Dict]:
        """Detecta anomalias no uso de recursos."""
        anomalies = []

        # Verificar CPU excessiva
        for proc in processes:
            if proc.cpu_percent > 80:
                anomalies.append({
                    "type": "high_cpu",
                    "severity": "high",
                    "message": f"Processo '{proc.name}' (PID {proc.pid}) usando {proc.cpu_percent}% de CPU",
                    "process_name": proc.name,
                    "pid": proc.pid,
                    "value": proc.cpu_percent
                })

        # Verificar memória excessiva
        for proc in processes:
            if proc.memory_percent > 20:
                anomalies.append({
                    "type": "high_memory",
                    "severity": "medium",
                    "message": f"Processo '{proc.name}' (PID {proc.pid}) usando {proc.memory_percent}% de memória",
                    "process_name": proc.name,
                    "pid": proc.pid,
                    "value": proc.memory_percent
                })

        # Verificar mudanças súbitas no uso
        for proc in processes:
            if proc.pid in self._baseline_memory:
                if proc.memory_percent > self._baseline_memory[proc.pid] * 3:
                    anomalies.append({
                        "type": "memory_spike",
                        "severity": "high",
                        "message": f"Processo '{proc.name}' com pico de memória: "
                                   f"{self._baseline_memory[proc.pid]:.1f}% -> {proc.memory_percent:.1f}%",
                        "process_name": proc.name,
                        "pid": proc.pid,
                        "old_value": self._baseline_memory[proc.pid],
                        "new_value": proc.memory_percent
                    })

        return anomalies

    def _detect_new_processes(self, processes: List[ProcessInfo]) -> List[Dict]:
        """Detecta processos novos não presentes no baseline."""
        new = []
        for proc in processes:
            if proc.pid not in self._baseline_cpu:
                new.append({
                    "name": proc.name,
                    "pid": proc.pid,
                    "cmdline": proc.cmdline[:100],
                    "user": proc.user,
                    "memory_percent": proc.memory_percent
                })
        return new

    def _calculate_risk(self, result, anomalies: List[Dict]) -> float:
        """Calcula score de risco."""
        severity_weights = {"critical": 40, "high": 25, "medium": 10, "low": 2}

        process_score = sum(
            severity_weights.get(p.risk_level, 2)
            for p in result.processes if p.is_suspicious
        )
        anomaly_score = sum(
            severity_weights.get(a.get("severity", "low"), 5)
            for a in anomalies
        )

        total = process_score + anomaly_score
        return min(100, total / max(len(result.processes), 1) * 3)

    def _generate_recommendations(self, result, anomalies: List[Dict]) -> List[str]:
        """Gera recomendações."""
        recs = []

        for proc in result.processes:
            if proc.risk_level == "critical":
                recs.append(f"Terminar processo crítico: {proc.name} (PID {proc.pid})")
            elif proc.risk_level == "high":
                recs.append(f"Investigar processo de alto risco: {proc.name} (PID {proc.pid})")

        for anomaly in anomalies:
            if anomaly.get("severity") in ["critical", "high"]:
                recs.append(f"Anomalia: {anomaly['message']}")

        if not recs:
            recs.append("Processos dentro do padrão normal")

        return recs

    def start_monitoring(self, callback=None):
        """Inicia monitoramento contínuo de processos."""
        def alert_callback(proc_info):
            if callback:
                callback(proc_info)

        self.scanner.monitor_process_creation(callback=alert_callback)

    def stop_monitoring(self):
        """Para monitoramento."""
        self.scanner.stop_monitoring()

    @property
    def scan_count(self) -> int:
        return self._scan_count
