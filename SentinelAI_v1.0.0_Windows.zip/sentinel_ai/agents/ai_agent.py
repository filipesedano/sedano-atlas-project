"""
Agente de IA - Analista.
Responsável por: receber todas as informações dos outros agentes,
analisar padrões, calcular probabilidades, gerar recomendações.
"""

import json
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

from ..config import config

logger = logging.getLogger("sentinel.agent.ai")


@dataclass
class ThreatAnalysis:
    """Análise de ameaça gerada pela IA."""
    threat_type: str
    probability: float  # 0-100%
    confidence: float   # 0-100%
    risk_level: str     # low, medium, high, critical
    description: str
    evidence: List[str]
    affected_areas: List[str]
    recommendations: List[str]
    mitigations: List[str]
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class ComprehensiveReport:
    """Relatório abrangente da IA."""
    overall_risk_score: float
    threat_count: int
    threats: List[ThreatAnalysis]
    summary: str
    immediate_actions: List[str]
    short_term_actions: List[str]
    long_term_actions: List[str]
    system_health: Dict
    timestamp: datetime = field(default_factory=datetime.now)


class AIAgent:
    """Agente de IA - Analista principal."""

    def __init__(self):
        self.config = config
        self._analysis_history: List[ThreatAnalysis] = []
        self._pattern_database: Dict[str, Dict] = {}
        self._threat_patterns = self._load_threat_patterns()
        self._learning_data: List[Dict] = []

    def _load_threat_patterns(self) -> Dict[str, Dict]:
        """Carrega padrões de ameaças conhecidos."""
        return {
            "ransomware": {
                "indicators": [
                    "many_files_modified_recently",
                    "encryption_extensions_detected",
                    "mass_file_encryption",
                    "ransom_note_created",
                    "suspicious_cryptographic_activity"
                ],
                "weight": 0.95,
                "description": "Ransomware - Criptografia maliciosa de arquivos",
                "immediate_actions": [
                    "Isolar a máquina da rede imediatamente",
                    "Não desligar o computador",
                    "Não tentar decryptar manualmente",
                    "Documentar os arquivos afetados"
                ]
            },
            "trojan": {
                "indicators": [
                    "suspicious_process_running",
                    "unusual_network_connection",
                    "modified_system_files",
                    "hidden_files_in_temp",
                    "reverse_shell_detected"
                ],
                "weight": 0.85,
                "description": "Trojan - Programa malicioso disfarçado",
                "immediate_actions": [
                    "Terminar o processo suspeito",
                    "Remover o arquivo do trojan",
                    "Verificar persistência no sistema",
                    "Mudar senhas comprometidas"
                ]
            },
            "backdoor": {
                "indicators": [
                    "unknown_service_running",
                    "modified_ssh_config",
                    "new_user_account_created",
                    "persistence_mechanism_detected",
                    "encrypted_tunnel_detected"
                ],
                "weight": 0.80,
                "description": "Backdoor - Acesso remoto não autorizado",
                "immediate_actions": [
                    "Desconectar da rede",
                    "Remover contas não autorizadas",
                    "Verificar configurações de acesso remoto",
                    "Auditar todas as conexões ativas"
                ]
            },
            "keylogger": {
                "indicators": [
                    "keyboard_hook_detected",
                    "suspicious_process_monitoring_input",
                    "data_exfiltration_detected",
                    "unusual_network_traffic_outbound"
                ],
                "weight": 0.75,
                "description": "Keylogger - Captura de dados digitados",
                "immediate_actions": [
                    "Remover o processo imediatamente",
                    "Mudar todas as senhas",
                    "Verificar dados financeiros",
                    "Monitorar contas bancárias"
                ]
            },
            "cryptominer": {
                "indicators": [
                    "high_cpu_usage_unexplained",
                    "mining_pool_connection",
                    "suspicious_process_name",
                    "high_gpu_usage",
                    "unusual_network_traffic"
                ],
                "weight": 0.70,
                "description": "Cryptominer - Mineração não autorizada",
                "immediate_actions": [
                    "Terminar processo de mineração",
                    "Bloquear conexão com pool",
                    "Verificar scripts de persistência",
                    "Monitorar uso de recursos"
                ]
            },
            "rootkit": {
                "indicators": [
                    "hidden_processes_detected",
                    "modified_kernel_modules",
                    "system_call_hooking",
                    "filesystem_manipulation",
                    "network_stealth_detected"
                ],
                "weight": 0.90,
                "description": "Rootkit - Malware com acesso root",
                "immediate_actions": [
                    "Isolar a máquina imediatamente",
                    "Realizar boot com sistema limpo",
                    "Verificar integridade do kernel",
                    "Considerar reinstalação do sistema"
                ]
            },
            "data_exfiltration": {
                "indicators": [
                    "large_data_transfer_outbound",
                    "unusual_upload_patterns",
                    "encrypted_outbound_traffic",
                    "connection_to_unknown_server",
                    "data_compression_before_transfer"
                ],
                "weight": 0.85,
                "description": "Exfiltração de Dados - Roubo de informações",
                "immediate_actions": [
                    "Bloquear tráfego de saída",
                    "Isolar a máquina da rede",
                    "Identificar dados potencialmente roubados",
                    "Notificar equipe de segurança"
                ]
            },
            "brute_force": {
                "indicators": [
                    "multiple_failed_logins",
                    "repeated_authentication_attempts",
                    "login_from_unknown_location",
                    "account_lockout_events"
                ],
                "weight": 0.65,
                "description": "Ataque de Força Bruta",
                "immediate_actions": [
                    "Bloquear IPs ofensores",
                    "Habilitar 2FA se disponível",
                    "Alterar senhas comprometidas",
                    "Implementar rate limiting"
                ]
            },
            "phishing": {
                "indicators": [
                    "suspicious_email_attachment",
                    "fake_login_page_detected",
                    "credential_harvesting_attempt",
                    "redirect_to_malicious_site"
                ],
                "weight": 0.60,
                "description": "Phishing - Enganação para obter credenciais",
                "immediate_actions": [
                    "Não inserir dados em páginas suspeitas",
                    "Verificar URLs cuidadosamente",
                    "Reportar o ataque",
                    "Mudar credenciais se comprometidas"
                ]
            }
        }

    def analyze_all_data(self, file_report: Dict = None,
                         network_report: Dict = None,
                         log_report: Dict = None,
                         process_report: Dict = None,
                         config_report: Dict = None) -> ComprehensiveReport:
        """Analisa todas as informações e gera relatório abrangente."""
        logger.info("Iniciando análise abrangente da IA")

        threats = []
        all_evidence = []
        all_risk_scores = []

        # Coletar todas as evidências
        if file_report:
            evidence = self._extract_evidence(file_report, "file")
            all_evidence.extend(evidence)
            if file_report.get("risk_score", 0) > 0:
                all_risk_scores.append(("file", file_report["risk_score"]))

        if network_report:
            evidence = self._extract_evidence(network_report, "network")
            all_evidence.extend(evidence)
            if network_report.get("risk_score", 0) > 0:
                all_risk_scores.append(("network", network_report["risk_score"]))

        if log_report:
            evidence = self._extract_evidence(log_report, "log")
            all_evidence.extend(evidence)
            if log_report.get("risk_score", 0) > 0:
                all_risk_scores.append(("log", log_report["risk_score"]))

        if process_report:
            evidence = self._extract_evidence(process_report, "process")
            all_evidence.extend(evidence)
            if process_report.get("risk_score", 0) > 0:
                all_risk_scores.append(("process", process_report["risk_score"]))

        if config_report:
            evidence = self._extract_evidence(config_report, "config")
            all_evidence.extend(evidence)
            if config_report.get("risk_score", 0) > 0:
                all_risk_scores.append(("config", config_report["risk_score"]))

        # Detectar ameaças
        threats = self._detect_threats(all_evidence)

        # Calcular risco geral
        overall_risk = self._calculate_overall_risk(threats, all_risk_scores)

        # Gerar resumo
        summary = self._generate_summary(threats, overall_risk, all_risk_scores)

        # Gerar ações
        immediate, short_term, long_term = self._generate_actions(threats)

        # Saúde do sistema
        system_health = self._assess_system_health(all_risk_scores)

        report = ComprehensiveReport(
            overall_risk_score=overall_risk,
            threat_count=len(threats),
            threats=threats,
            summary=summary,
            immediate_actions=immediate,
            short_term_actions=short_term,
            long_term_actions=long_term,
            system_health=system_health
        )

        self._analysis_history.extend(threats)
        logger.info(f"Análise completa: {len(threats)} ameaças, "
                     f"risco geral: {overall_risk:.1f}%")
        return report

    def _extract_evidence(self, report: Dict, source: str) -> List[Dict]:
        """Extrai evidências de um relatório."""
        evidence = []

        if source == "file":
            if report.get("suspicious_files", 0) > 0:
                evidence.append({
                    "type": "suspicious_files",
                    "value": report["suspicious_files"],
                    "source": "file_agent"
                })
            if report.get("encryption_suspicion"):
                for e in report["encryption_suspicion"]:
                    evidence.append({
                        "type": "encryption_suspicion",
                        "value": e.get("type", "unknown"),
                        "source": "file_agent",
                        "detail": e.get("detail", "")
                    })
            if report.get("altered_files"):
                evidence.append({
                    "type": "altered_files",
                    "value": len(report["altered_files"]),
                    "source": "file_agent"
                })

        elif source == "network":
            if report.get("suspicious_connections", 0) > 0:
                evidence.append({
                    "type": "suspicious_connections",
                    "value": report["suspicious_connections"],
                    "source": "network_agent"
                })
            if report.get("traffic_anomalies"):
                for a in report["traffic_anomalies"]:
                    evidence.append({
                        "type": "network_anomaly",
                        "value": a.get("type", "unknown"),
                        "source": "network_agent",
                        "detail": a.get("message", "")
                    })

        elif source == "log":
            if report.get("patterns_detected"):
                for p in report["patterns_detected"]:
                    evidence.append({
                        "type": "log_pattern",
                        "value": p.get("pattern_name", "unknown"),
                        "source": "log_agent",
                        "detail": p.get("description", "")
                    })

        elif source == "process":
            if report.get("suspicious_processes", 0) > 0:
                evidence.append({
                    "type": "suspicious_processes",
                    "value": report["suspicious_processes"],
                    "source": "process_agent"
                })

        elif source == "config":
            if report.get("suspicious_modifications", 0) > 0:
                evidence.append({
                    "type": "config_changes",
                    "value": report["suspicious_modifications"],
                    "source": "config_agent"
                })

        return evidence

    def _detect_threats(self, evidence: List[Dict]) -> List[ThreatAnalysis]:
        """Detecta ameaças baseado nas evidências."""
        threats = []

        for threat_name, pattern in self._threat_patterns.items():
            matched_indicators = 0
            total_indicators = len(pattern["indicators"])
            matched_evidence = []

            for indicator in pattern["indicators"]:
                for ev in evidence:
                    ev_type = str(ev.get("type", ""))
                    ev_value = str(ev.get("value", ""))
                    if indicator in ev_type or indicator in ev_value:
                        matched_indicators += 1
                        matched_evidence.append(ev.get("detail", ev.get("value", "")))

            # Calcular probabilidade
            if total_indicators > 0 and matched_indicators > 0:
                match_ratio = matched_indicators / total_indicators
                probability = min(99, match_ratio * pattern["weight"] * 100)
                confidence = min(95, match_ratio * 80 + 20)

                if probability > 15:  # Limiar mínimo
                    severity = self._probability_to_severity(probability)
                    threats.append(ThreatAnalysis(
                        threat_type=threat_name,
                        probability=probability,
                        confidence=confidence,
                        risk_level=severity,
                        description=pattern["description"],
                        evidence=matched_evidence,
                        affected_areas=["system"],
                        recommendations=pattern.get("immediate_actions", []),
                        mitigations=self._get_mitigations(threat_name)
                    ))

        # Ordenar por probabilidade
        threats.sort(key=lambda x: x.probability, reverse=True)
        return threats

    def _probability_to_severity(self, probability: float) -> str:
        """Converte probabilidade para nível de severidade."""
        if probability >= 80:
            return "critical"
        elif probability >= 60:
            return "high"
        elif probability >= 40:
            return "medium"
        return "low"

    def _get_mitigations(self, threat_type: str) -> List[str]:
        """Retorna medidas de mitigação para uma ameaça."""
        mitigations = {
            "ransomware": [
                "Manter backups regulares e offline",
                "Manter sistema atualizado",
                "Educar usuários sobre phishing",
                "Implementar políticas de backup 3-2-1"
            ],
            "trojan": [
                "Usar apenas software de fontes confiáveis",
                "Manter antivírus atualizado",
                "Não executar arquivos desconhecidos",
                "Verificar integridade de downloads"
            ],
            "backdoor": [
                "Auditar regularmente o sistema",
                "Monitorar conexões de rede",
                "Usar autenticação forte",
                "Limitar acesso remoto"
            ],
            "keylogger": [
                "Usar gerenciador de senhas",
                "Habilitar 2FA em todas as contas",
                "Monitorar atividade de teclado",
                "Verificar processos regularmente"
            ],
            "cryptominer": [
                "Monitorar uso de CPU/GPU",
                "Bloquear domínios de mining pools",
                "Restringir execução de scripts",
                "Auditar processos do sistema"
            ],
            "rootkit": [
                "Usar sistemas de detecção de rootkit",
                "Manter kernel atualizado",
                "Verificar módulos do kernel",
                "Considerar reinstalação se comprometido"
            ]
        }
        return mitigations.get(threat_type, ["Auditar o sistema", "Manter atualizações em dia"])

    def _calculate_overall_risk(self, threats: List[ThreatAnalysis],
                                 risk_scores: List[Tuple]) -> float:
        """Calcula risco geral do sistema."""
        if not threats and not risk_scores:
            return 0

        threat_weight = 0.7
        score_weight = 0.3

        # Peso das ameaças
        if threats:
            max_probability = max(t.probability for t in threats)
            avg_probability = sum(t.probability for t in threats) / len(threats)
            threat_risk = max_probability * 0.6 + avg_probability * 0.4
        else:
            threat_risk = 0

        # Peso dos scores
        if risk_scores:
            avg_score = sum(s for _, s in risk_scores) / len(risk_scores)
        else:
            avg_score = 0

        overall = (threat_risk * threat_weight) + (avg_score * score_weight)
        return min(100, overall)

    def _generate_summary(self, threats: List[ThreatAnalysis],
                          overall_risk: float,
                          risk_scores: List[Tuple]) -> str:
        """Gera resumo executivo."""
        if overall_risk == 0:
            return "Sistema operacional. Nenhuma ameaça detectada no momento."

        if overall_risk < 30:
            status = "risco baixo"
        elif overall_risk < 60:
            status = "risco moderado"
        elif overall_risk < 80:
            status = "risco alto"
        else:
            status = "risco crítico"

        parts = [
            f"Sistema em {status} ({overall_risk:.1f}%).",
            f"{len(threats)} ameaça(s) potencial(is) detectada(s)."
        ]

        if threats:
            top_threat = threats[0]
            parts.append(
                f"Ameaça principal: {top_threat.threat_type} "
                f"(probabilidade: {top_threat.probability:.1f}%)"
            )

        return " ".join(parts)

    def _generate_actions(self, threats: List[ThreatAnalysis]) -> Tuple[List, List, List]:
        """Gera ações recomendadas."""
        immediate = []
        short_term = []
        long_term = []

        for threat in threats:
            if threat.risk_level == "critical":
                immediate.extend([
                    f"URGENTE: {r}" for r in threat.recommendations[:3]
                ])
            elif threat.risk_level == "high":
                short_term.extend([
                    f"Recomendado: {r}" for r in threat.recommendations[:2]
                ])

        # Ações gerais
        if immediate:
            short_term.append("Realizar scan completo do sistema")
            long_term.append("Implementar monitoramento contínuo")
        else:
            short_term.append("Manter scans regulares")

        long_term.extend([
            "Manter sistema e software atualizados",
            "Educar usuários sobre segurança",
            "Implementar políticas de backup",
            "Revisar políticas de segurança periodicamente"
        ])

        return immediate, short_term, long_term

    def _assess_system_health(self, risk_scores: List[Tuple]) -> Dict:
        """Avalia a saúde geral do sistema."""
        if not risk_scores:
            return {"status": "healthy", "score": 100}

        avg = sum(s for _, s in risk_scores) / len(risk_scores)
        min_score = min(s for _, s in risk_scores)

        if avg < 20 and min_score < 20:
            status = "healthy"
        elif avg < 50:
            status = "warning"
        elif avg < 70:
            status = "degraded"
        else:
            status = "critical"

        return {
            "status": status,
            "score": max(0, 100 - avg),
            "areas": dict(risk_scores),
            "weakest_area": min(risk_scores, key=lambda x: x[1])[0]
        }

    def get_analysis_history(self) -> List[ThreatAnalysis]:
        """Retorna histórico de análises."""
        return self._analysis_history.copy()

    def learn_from_feedback(self, threat: str, was_false_positive: bool):
        """Aprende com feedback do usuário."""
        self._learning_data.append({
            "threat": threat,
            "false_positive": was_false_positive,
            "timestamp": datetime.now().isoformat()
        })

        if was_false_positive:
            # Reduzir peso do padrão
            if threat in self._threat_patterns:
                self._threat_patterns[threat]["weight"] *= 0.9

        logger.info(f"Aprendizado registrado: {threat} = {was_false_positive}")
