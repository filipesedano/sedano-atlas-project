"""
Agente de Rede.
Responsável por: monitorar conexões, detectar tráfego incomum,
verificar IPs e portas suspeitos, analisar padrões de rede.
"""

import logging
from typing import Dict, List, Optional
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

from ..scanner.network_scanner import NetworkScanner, NetworkAlert
from ..database.db_manager import DatabaseManager

logger = logging.getLogger("sentinel.agent.network")


@dataclass
class NetworkAgentReport:
    """Relatório do Agente de Rede."""
    total_connections: int
    suspicious_connections: int
    active_alerts: int
    traffic_anomalies: List[Dict]
    dns_anomalies: List[Dict]
    port_anomalies: List[Dict]
    risk_score: float  # 0-100
    summary: str
    recommendations: List[str]
    timestamp: datetime = field(default_factory=datetime.now)


class NetworkAgent:
    """Agente especializado em análise de rede."""

    def __init__(self, db_manager: Optional[DatabaseManager] = None):
        self.scanner = NetworkScanner()
        self.db = db_manager
        self._scan_count = 0
        self._connection_history: List[Dict] = []
        self._anomaly_threshold = 5  # Número de anomalias para alertar

    def full_scan(self) -> NetworkAgentReport:
        """Realiza scan completo da rede."""
        logger.info("Iniciando scan completo de rede")

        # Scan de conexões
        connection_result = self.scanner.scan_connections()

        # Verificar anomalias DNS
        dns_alerts = self.scanner.check_dns_anomalies()

        # Verificar portas abertas
        port_alerts = self.scanner.check_open_ports()

        # Calcular score de risco
        risk_score = self._calculate_risk_score(
            connection_result, dns_alerts, port_alerts
        )

        # Gerar resumo
        summary = self._generate_summary(
            connection_result, dns_alerts, port_alerts
        )

        # Gerar recomendações
        recommendations = self._generate_recommendations(
            connection_result, dns_alerts, port_alerts
        )

        report = NetworkAgentReport(
            total_connections=connection_result.total_connections,
            suspicious_connections=sum(
                1 for a in connection_result.alerts
                if a.severity in ["high", "critical"]
            ),
            active_alerts=len(connection_result.alerts) + len(dns_alerts) + len(port_alerts),
            traffic_anomalies=[{
                "type": a.alert_type,
                "severity": a.severity,
                "message": a.message
            } for a in connection_result.alerts],
            dns_anomalies=[{
                "type": a.alert_type,
                "severity": a.severity,
                "message": a.message
            } for a in dns_alerts],
            port_anomalies=[{
                "type": a.alert_type,
                "severity": a.severity,
                "message": a.message
            } for a in port_alerts],
            risk_score=risk_score,
            summary=summary,
            recommendations=recommendations
        )

        # Salvar no banco
        if self.db:
            self.db.save_scan_result("network_scan", report)

        self._scan_count += 1
        logger.info(f"Scan de rede concluído. Risco: {risk_score:.1f}%")
        return report

    def start_monitoring(self, callback=None):
        """Inicia monitoramento contínuo de rede."""
        def alert_callback(alert):
            if callback:
                callback(alert)
            # Salvar alerta no banco
            if self.db:
                self.db.save_alert(
                    "network", alert.alert_type, alert.severity, alert.message
                )

        self.scanner.start_monitoring(callback=alert_callback)
        logger.info("Monitoramento de rede iniciado")

    def stop_monitoring(self):
        """Para monitoramento de rede."""
        self.scanner.stop_monitoring()
        logger.info("Monitoramento de rede parado")

    def _calculate_risk_score(self, conn_result, dns_alerts, port_alerts) -> float:
        """Calcula score de risco de rede."""
        total_alerts = len(conn_result.alerts) + len(dns_alerts) + len(port_alerts)

        if total_alerts == 0:
            return 0

        # Ponderar por severidade
        severity_weights = {
            "critical": 40,
            "high": 25,
            "medium": 10,
            "low": 5
        }

        weighted_score = 0
        for alert in conn_result.alerts + dns_alerts + port_alerts:
            weighted_score += severity_weights.get(alert.severity, 5)

        return min(100, weighted_score)

    def _generate_summary(self, conn_result, dns_alerts, port_alerts) -> str:
        """Gera resumo do scan de rede."""
        total_alerts = len(conn_result.alerts) + len(dns_alerts) + len(port_alerts)
        parts = [f"{conn_result.total_connections} conexões ativas"]

        if total_alerts > 0:
            parts.append(f"{total_alerts} alertas de rede")

        if conn_result.scan_duration:
            parts.append(f"Scan em {conn_result.scan_duration:.2f}s")

        return "; ".join(parts)

    def _generate_recommendations(self, conn_result, dns_alerts, port_alerts) -> List[str]:
        """Gera recomendações."""
        recommendations = []

        for alert in conn_result.alerts:
            if alert.severity == "critical":
                recommendations.append(f"URGENTE: {alert.message}")
            elif alert.severity == "high":
                recommendations.append(f"Atenção: {alert.message}")

        if dns_alerts:
            recommendations.append("Verifique as configurações DNS do sistema")

        if port_alerts:
            recommendations.append("Revise as portas abertas e feche as desnecessárias")

        if not recommendations:
            recommendations.append("Rede aparentemente normal. Continue monitorando.")

        return recommendations

    def get_connection_summary(self) -> Dict:
        """Retorna resumo das conexões."""
        external_ips = defaultdict(int)
        for entry in self._connection_history:
            remote = entry.get("remote_address", "")
            if remote and remote != "0.0.0.0":
                external_ips[remote] += 1

        return {
            "total_unique_ips": len(external_ips),
            "top_connections": dict(sorted(
                external_ips.items(), key=lambda x: x[1], reverse=True
            )[:10])
        }

    @property
    def scan_count(self) -> int:
        return self._scan_count
