"""
Módulo de Criptografia do Sentinel AI.
Responsável por: proteger dados do sistema, criptografar banco de dados,
gerenciar chaves de criptografia.
"""

import os
import hashlib
import secrets
import logging
from typing import Optional
from base64 import b64encode, b64decode

from ..config import config, ENCRYPTION_KEY_FILE

logger = logging.getLogger("sentinel.crypto")


class CryptoManager:
    """Gerenciador de criptografia do Sentinel AI."""

    def __init__(self):
        self.config = config
        self._master_key: Optional[bytes] = None
        self._salt: Optional[bytes] = None

    def generate_master_key(self) -> bytes:
        """Gera uma chave mestra segura."""
        key = secrets.token_bytes(32)  # 256 bits
        self._master_key = key

        # Gerar salt
        self._salt = secrets.token_bytes(16)

        # Salvar chave (criptografada com hash da chave)
        self._save_key(key)
        logger.info("Chave mestra gerada")
        return key

    def load_master_key(self) -> Optional[bytes]:
        """Carrega a chave mestra do arquivo."""
        if ENCRYPTION_KEY_FILE.exists():
            try:
                with open(ENCRYPTION_KEY_FILE, 'rb') as f:
                    stored = f.read()

                # Separar salt e chave criptografada
                salt_len = 16
                salt = stored[:salt_len]
                encrypted_key = stored[salt_len:]

                # Derivar chave de descriptografia
                derived = self._derive_key(b'sentinel_default', salt)

                # Simples XOR para descriptografar
                key = bytes(a ^ b for a, b in zip(encrypted_key, derived))

                self._master_key = key
                self._salt = salt
                logger.info("Chave mestra carregada")
                return key
            except Exception as e:
                logger.error(f"Erro ao carregar chave: {e}")

        return None

    def ensure_key_exists(self) -> bytes:
        """Garante que existe uma chave, gerando se necessário."""
        key = self.load_master_key()
        if key is None:
            key = self.generate_master_key()
        return key

    def encrypt_data(self, data: bytes) -> bytes:
        """Criptografa dados usando a chave mestra."""
        if self._master_key is None:
            self.ensure_key_exists()

        # Gerar nonce
        nonce = secrets.token_bytes(12)

        # XOR simples com derivação
        derived = self._derive_key(self._master_key, nonce[:16] if len(nonce) >= 16 else nonce)
        encrypted = bytes(a ^ b for a, b in zip(data, derived))

        # Retornar nonce + dados criptografados
        return nonce + encrypted

    def decrypt_data(self, encrypted_data: bytes) -> bytes:
        """Descriptografa dados usando a chave mestra."""
        if self._master_key is None:
            self.ensure_key_exists()

        nonce_len = 12
        nonce = encrypted_data[:nonce_len]
        ciphertext = encrypted_data[nonce_len:]

        derived = self._derive_key(self._master_key, nonce[:16] if len(nonce) >= 16 else nonce)
        decrypted = bytes(a ^ b for a, b in zip(ciphertext, derived))

        return decrypted

    def hash_password(self, password: str, salt: bytes = None) -> str:
        """Cria hash de senha com salt."""
        if salt is None:
            salt = secrets.token_bytes(16)

        # PBKDF2-like com SHA-256
        iterations = 100000
        key = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, iterations)
        return f"{b64encode(salt).decode()}:${b64encode(key).decode()}"

    def verify_password(self, password: str, hashed: str) -> bool:
        """Verifica uma senha contra seu hash."""
        try:
            salt_b64, key_b64 = hashed.split('$')
            salt = b64decode(salt_b64)
            stored_key = b64decode(key_b64)

            iterations = 100000
            computed = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, iterations)

            # Comparação constante no tempo
            return secrets.compare_digest(computed, stored_key)
        except (ValueError, Exception) as e:
            logger.error(f"Erro ao verificar senha: {e}")
            return False

    def encrypt_file(self, file_path: str) -> bool:
        """Criptografa um arquivo."""
        try:
            if self._master_key is None:
                self.ensure_key_exists()

            with open(file_path, 'rb') as f:
                data = f.read()

            encrypted = self.encrypt_data(data)

            with open(file_path + '.encrypted', 'wb') as f:
                f.write(encrypted)

            # Remover arquivo original
            os.remove(file_path)
            logger.info(f"Arquivo criptografado: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Erro ao criptografar arquivo: {e}")
            return False

    def decrypt_file(self, file_path: str) -> bool:
        """Descriptografa um arquivo."""
        try:
            if self._master_key is None:
                self.ensure_key_exists()

            with open(file_path, 'rb') as f:
                encrypted = f.read()

            decrypted = self.decrypt_data(encrypted)

            # Remover extensão .encrypted
            output_path = file_path.rsplit('.encrypted', 1)[0]
            with open(output_path, 'wb') as f:
                f.write(decrypted)

            os.remove(file_path)
            logger.info(f"Arquivo descriptografado: {file_path}")
            return True
        except Exception as e:
            logger.error(f"Erro ao descriptografar arquivo: {e}")
            return False

    def sign_data(self, data: bytes) -> str:
        """Assina dados com HMAC."""
        if self._master_key is None:
            self.ensure_key_exists()

        import hmac
        signature = hmac.new(self._master_key, data, hashlib.sha256).hexdigest()
        return signature

    def verify_signature(self, data: bytes, signature: str) -> bool:
        """Verifica assinatura HMAC."""
        import hmac
        if self._master_key is None:
            self.ensure_key_exists()

        computed = hmac.new(self._master_key, data, hashlib.sha256).hexdigest()
        return hmac.compare_digest(computed, signature)

    def _save_key(self, key: bytes):
        """Salva a chave mestra criptografada."""
        try:
            # Derivar chave de proteção
            derived = self._derive_key(b'sentinel_default', self._salt)

            # XOR para "criptografar" a chave armazenada
            encrypted_key = bytes(a ^ b for a, b in zip(key, derived))

            with open(ENCRYPTION_KEY_FILE, 'wb') as f:
                f.write(self._salt + encrypted_key)
        except Exception as e:
            logger.error(f"Erro ao salvar chave: {e}")

    def _derive_key(self, password: bytes, salt: bytes) -> bytes:
        """Deriva chave usando PBKDF2."""
        return hashlib.pbkdf2_hmac('sha256', password, salt, 100000, dklen=32)

    def get_key_info(self) -> dict:
        """Retorna informações sobre a chave (sem expor a chave)."""
        from typing import Dict
        return {
            "key_exists": self._master_key is not None,
            "algorithm": "AES-256-GCM (simulado)",
            "key_length": 256,
            "salt_length": 128,
            "iterations": 100000
        }


# Instância global
crypto = CryptoManager()
