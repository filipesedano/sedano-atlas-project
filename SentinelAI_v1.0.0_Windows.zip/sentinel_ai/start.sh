#!/bin/bash
# Sentinel AI - Launcher Linux
GREEN='\033[0;32m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "  ${BLUE}SENTINEL AI${NC} - Sistema de Segurança Inteligente"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERRO] Python 3 não encontrado!${NC}"
    echo "Instale com: sudo apt install python3 python3-pip"
    exit 1
fi

echo -e "${GREEN}[OK]${NC} Python encontrado: $(python3 --version 2>&1)"

# Instalar dependências
echo "Instalando dependências..."
pip3 install customtkinter --quiet --user 2>/dev/null || python3 -m pip install customtkinter --quiet --user

if [ $? -ne 0 ]; then
    echo -e "${RED}[ERRO] Falha ao instalar dependências.${NC}"
    exit 1
fi

echo -e "${GREEN}[OK]${NC} Dependências prontas."
echo ""
echo "Iniciando Sentinel AI..."
echo ""
python3 -m sentinel_ai.main --gui
