"""
Scanner de Processos e Sistema.
Responsável por: verificar processos, monitorar memória,
verificar registro (Linux: /etc e configs), detectar anomalias.
"""

import os
import re
import time
import threading
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from ..config import config

logger = logging.getLogger("sentinel.scanner.process")


@dataclass
class ProcessInfo:
    """Informações sobre um processo."""
    pid: int
    name: str
    cmdline: str
    status: str
    cpu_percent: float
    memory_percent: float
    user: str
    exe_path: Optional[str]
    is_suspicious: bool = False
    risk_level: str = "low"
    details: List[str] = field(default_factory=list)


@dataclass
class SystemAlert:
    """Alerta do sistema."""
    alert_type: str
    severity: str
    message: str
    details: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class SystemScanResult:
    """Resultado do scan do sistema."""
    total_processes: int
    suspicious_processes: int
    processes: List[ProcessInfo]
    alerts: List[SystemAlert]
    memory_usage: Dict = field(default_factory=dict)
    scan_duration: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)


class ProcessScanner:
    """Scanner de processos e sistema do Sentinel AI."""

    def __init__(self):
        self.config = config
        self._process_history: List[ProcessInfo] = []
        self._alerts: List[SystemAlert] = []
        self._known_processes: Dict[int, str] = {}
        self._is_monitoring = False

    def scan_processes(self) -> SystemScanResult:
        """Escanea todos os processos ativos."""
        start_time = time.time()
        processes = []
        alerts = []

        try:
            # Ler /proc para obter processos
            for pid_dir in os.listdir('/proc'):
                if not pid_dir.isdigit():
                    continue

                pid = int(pid_dir)
                process_info = self._get_process_info(pid)
                if process_info:
                    processes.append(process_info)

                    # Verificar se o processo é suspeito
                    self._check_process(process_info, alerts)

        except (PermissionError, OSError) as e:
            alerts.append(SystemAlert(
                alert_type="scan_error",
                severity="medium",
                message=f"Erro parcial ao escanear processos: {str(e)}"
            ))

        # Verificar processos novos/desconhecidos
        new_processes = []
        for proc in processes:
            if proc.pid not in self._known_processes:
                new_processes.append(proc)

        if new_processes:
            alerts.append(SystemAlert(
                alert_type="new_processes",
                severity="medium",
                message=f"{len(new_processes)} processos novos detectados",
                details={"processes": [p.name for p in new_processes]}
            ))

        # Atualizar histórico
        self._known_processes = {p.pid: p.name for p in processes}
        self._process_history.extend(processes)
        self._alerts.extend(alerts)

        return SystemScanResult(
            total_processes=len(processes),
            suspicious_processes=sum(1 for p in processes if p.is_suspicious),
            processes=processes,
            alerts=alerts,
            memory_usage=self._get_memory_usage(),
            scan_duration=time.time() - start_time
        )

    def _get_process_info(self, pid: int) -> Optional[ProcessInfo]:
        """Obtém informações de um processo."""
        try:
            proc_dir = f'/proc/{pid}'

            # Nome do processo
            name = "unknown"
            try:
                with open(f'{proc_dir}/comm', 'r') as f:
                    name = f.read().strip()
            except (IOError, PermissionError):
                try:
                    with open(f'{proc_dir}/status', 'r') as f:
                        for line in f:
                            if line.startswith('Name:'):
                                name = line.split(':', 1)[1].strip()
                                break
                except (IOError, PermissionError):
                    pass

            # Linha de comando
            cmdline = ""
            try:
                with open(f'{proc_dir}/cmdline', 'rb') as f:
                    cmdline = f.read().decode('utf-8', errors='replace').replace('\x00', ' ').strip()
            except (IOError, PermissionError):
                pass

            # Status
            status = "unknown"
            cpu_percent = 0.0
            memory_percent = 0.0
            user = "unknown"
            try:
                with open(f'{proc_dir}/status', 'r') as f:
                    for line in f:
                        if line.startswith('State:'):
                            state = line.split(':', 1)[1].strip()
                            state_map = {
                                'R': 'running', 'S': 'sleeping', 'D': 'disk_sleep',
                                'T': 'stopped', 'Z': 'zombie', 'X': 'dead',
                                'I': 'idle'
                            }
                            state_char = state[0] if state else '?'
                            status = state_map.get(state_char, f"unknown({state_char})")
                        elif line.startswith('Uid:'):
                            uid = int(line.split(':')[1].strip().split()[0])
                            # Tentar mapear UID para user
                            user_map = {0: 'root', 1: 'daemon'}
                            user = user_map.get(uid, f'uid_{uid}')
            except (IOError, PermissionError):
                pass

            # Uso de memória
            try:
                with open(f'{proc_dir}/status', 'r') as f:
                    for line in f:
                        if line.startswith('VmRSS:'):
                            rss_kb = int(line.split(':')[1].strip().split()[0])
                            total_mem = self._get_total_memory_kb()
                            if total_mem > 0:
                                memory_percent = (rss_kb / total_mem) * 100
            except (IOError, PermissionError, ValueError):
                pass

            # Path do executável
            exe_path = None
            try:
                exe_path = os.readlink(f'{proc_dir}/exe')
            except (OSError, PermissionError):
                pass

            return ProcessInfo(
                pid=pid,
                name=name,
                cmdline=cmdline,
                status=status,
                cpu_percent=cpu_percent,
                memory_percent=memory_percent,
                user=user,
                exe_path=exe_path
            )
        except (PermissionError, OSError):
            return None

    def _check_process(self, process: ProcessInfo, alerts: List[SystemAlert]):
        """Verifica se um processo é suspeito."""
        details = []

        # Verificar nome do processo
        suspicious_names = [
            'cryptominer', 'xmrig', 'minerd', 'cgminer', 'bfgminer',
            'keylogger', 'spyware', 'backdoor', 'rat_server', 'trojan',
            'exploit', 'payload', 'shell', 'bindshell', 'reverseshell'
        ]
        name_lower = process.name.lower()
        for suspicious in suspicious_names:
            if suspicious in name_lower:
                details.append(f"Nome de processo suspeito: '{process.name}'")
                break

        # Verificar se está rodando como root sem ser sistema
        system_processes = [
            'init', 'systemd', 'kthreadd', 'ksoftirqd', 'kworker',
            'migration', 'watchdog', 'rcu_', 'kauditd', 'khungtaskd',
            'oom_reaper', 'writeback', 'kcompactd', 'ksmd', 'khugepaged',
            'kintegrityd', 'kblockd', 'ata_sff', 'scsi_', 'edac_',
            'devfreq_wq', 'watchdogd', 'bash', 'sh', 'zsh', 'fish',
            'python', 'python3', 'node', 'java', 'ruby', 'perl',
            'php', 'nginx', 'apache', 'httpd', 'sshd', 'cron', 'atd',
            'dbus', 'systemd-', 'udev', 'acpid', 'journald'
        ]
        if process.user == 'root' and process.pid > 1:
            is_system = any(process.name.startswith(sp) for sp in system_processes)
            if not is_system:
                details.append(f"Processo '{process.name}' rodando como root")

        # Verificar memória excessiva
        if process.memory_percent > 30:
            details.append(f"Uso de memória excessivo: {process.memory_percent:.1f}%")

        # Verificar linha de comando suspeita
        cmdline_lower = process.cmdline.lower()
        suspicious_patterns_cmd = [
            '-enc', 'bypass', 'hidden', 'windowstyle hidden',
            'powershell', '-nop', '-exec bypass', 'downloadstring',
            'invoke-webrequest', 'wget', 'curl', 'nc ', 'netcat',
            'socat', 'reverse shell', 'bind shell'
        ]
        for pattern in suspicious_patterns_cmd:
            if pattern in cmdline_lower:
                details.append(f"Comando suspeito detectado: '{pattern}'")
                break

        # Verificar process path suspeito
        if process.exe_path:
            path_lower = process.exe_path.lower()
            suspicious_paths = ['/tmp/', '/var/tmp/', '/dev/shm/', '/tmp/.', '/var/tmp/.']
            for sp in suspicious_paths:
                if path_lower.startswith(sp):
                    details.append(f"Executável em diretório temporário: {process.exe_path}")
                    break

        if details:
            process.is_suspicious = True
            process.details = details
            process.risk_level = self._calculate_risk(details)

            alerts.append(SystemAlert(
                alert_type="suspicious_process",
                severity=process.risk_level,
                message=f"Processo suspeito detectado: {process.name} (PID: {process.pid})",
                details={"process": process.name, "pid": process.pid, "details": details}
            ))

    def _calculate_risk(self, details: List[str]) -> str:
        """Calcula nível de risco."""
        critical_keywords = ['root', 'backdoor', 'trojan', 'exploit', 'shell', 'hidden']
        details_text = " ".join(details).lower()

        for kw in critical_keywords:
            if kw in details_text:
                return "critical"

        if len(details) >= 2:
            return "high"
        return "medium"

    def _get_memory_usage(self) -> Dict:
        """Obtém uso geral de memória."""
        mem = {}
        try:
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    parts = line.split(':')
                    if len(parts) == 2:
                        key = parts[0].strip()
                        value = parts[1].strip().split()[0]
                        if key in ['MemTotal', 'MemFree', 'MemAvailable', 'Buffers', 'Cached']:
                            mem[key] = int(value)
        except (IOError, PermissionError):
            pass
        return mem

    def _get_total_memory_kb(self) -> int:
        """Obtém memória total em KB."""
        try:
            with open('/proc/meminfo', 'r') as f:
                for line in f:
                    if line.startswith('MemTotal:'):
                        return int(line.split(':')[1].strip().split()[0])
        except (IOError, PermissionError, ValueError):
            pass
        return 0

    def check_system_integrity(self) -> List[SystemAlert]:
        """Verifica integridade do sistema."""
        alerts = []

        # Verificar processos zombie
        try:
            with open('/proc/loadavg', 'r') as f:
                content = f.read()
                # Último campo mostra processos zombie
                parts = content.strip().split()
                if len(parts) >= 4:
                    zombie_str = parts[3].split('/')[1]
                    zombie_count = int(zombie_str.split('/')[0])
                    if zombie_count > 0:
                        alerts.append(SystemAlert(
                            alert_type="zombie_processes",
                            severity="medium",
                            message=f"{zombie_count} processos zombie detectados",
                            details={"count": zombie_count}
                        ))
        except (IOError, ValueError):
            pass

        # Verificar arquivos /proc/sys/kernel para anomalias
        try:
            kernel_params = {}
            params_to_check = ['hostname', 'domainname', 'osrelease']
            for param in params_to_check:
                try:
                    with open(f'/proc/sys/kernel/{param}', 'r') as f:
                        kernel_params[param] = f.read().strip()
                except (IOError, PermissionError):
                    pass

            if kernel_params:
                # Verificar hostname suspeito
                hostname = kernel_params.get('hostname', '')
                if hostname and any(c in hostname for c in ['-', '_', 'tmp', 'bot']):
                    if hostname.lower() not in ['localhost', 'ubuntu', 'sentinel']:
                        alerts.append(SystemAlert(
                            alert_type="hostname_anomaly",
                            severity="low",
                            message=f"Hostname pode ser anômalo: {hostname}",
                            details={"hostname": hostname}
                        ))
        except Exception:
            pass

        # Verificar crontab do sistema
        try:
            crontab_files = [
                '/etc/crontab',
                '/etc/cron.d/',
            ]
            for cf in crontab_files:
                if os.path.isfile(cf):
                    with open(cf, 'r') as f:
                        content = f.read()
                        # Verificar por downloads ou execuções suspeitas
                        if any(kw in content.lower() for kw in
                               ['wget', 'curl', 'powershell', 'python', '/tmp/', '/dev/shm/']):
                            alerts.append(SystemAlert(
                                alert_type="crontab_anomaly",
                                severity="high",
                                message=f"Entrada suspeita em {cf}",
                                details={"file": cf, "content_preview": content[:200]}
                            ))
        except (IOError, PermissionError):
            pass

        return alerts

    def monitor_process_creation(self, callback=None):
        """Monitora criação de novos processos."""
        self._is_monitoring = True

        def monitor_loop():
            last_pids = set()
            while self._is_monitoring:
                try:
                    current_pids = set()
                    for pid_dir in os.listdir('/proc'):
                        if pid_dir.isdigit():
                            current_pids.add(int(pid_dir))

                    new_pids = current_pids - last_pids
                    if new_pids and callback:
                        for pid in new_pids:
                            proc_info = self._get_process_info(pid)
                            if proc_info:
                                callback(proc_info)

                    last_pids = current_pids
                except Exception as e:
                    logger.error(f"Erro no monitoramento de processos: {e}")

                time.sleep(2)

        threading.Thread(target=monitor_loop, daemon=True).start()
        logger.info("Monitoramento de processos iniciado")

    def stop_monitoring(self):
        """Para o monitoramento."""
        self._is_monitoring = False

    def get_alerts(self) -> List[SystemAlert]:
        return self._alerts.copy()

    def clear_alerts(self):
        self._alerts.clear()

    @property
    def is_monitoring(self) -> bool:
        return self._is_monitoring
