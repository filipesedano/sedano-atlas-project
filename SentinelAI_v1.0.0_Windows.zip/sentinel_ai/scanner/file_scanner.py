"""
Agente de Arquivos - Scanner de Arquivos.
Responsável por: verificar arquivos, identificar alterações,
detectar criptografia suspeita, calcular hashes.
"""

import hashlib
import os
import time
import threading
import logging
from pathlib import Path
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from ..config import config

logger = logging.getLogger("sentinel.scanner.file")


@dataclass
class FileScanResult:
    """Resultado da verificação de um arquivo."""
    path: str
    name: str
    size: int
    hash_value: str
    last_modified: datetime
    is_suspicious: bool
    risk_level: str = "low"  # low, medium, high, critical
    details: List[str] = field(default_factory=list)
    scanned_at: datetime = field(default_factory=datetime.now)


@dataclass
class DirectoryScanResult:
    """Resultado do scan de um diretório inteiro."""
    path: str = ""
    total_files: int = 0
    files_scanned: int = 0
    suspicious_files: int = 0
    results: List[FileScanResult] = field(default_factory=list)
    errors: List[str] = field(default_factory=list)
    scan_duration: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)


class FileScanner:
    """Scanner de arquivos do Sentinel AI."""

    def __init__(self):
        self.config = config
        self._hash_cache: Dict[str, str] = {}
        self._file_signatures = self._load_signatures()
        self._suspicious_patterns = self._load_suspicious_patterns()
        self._scan_lock = threading.Lock()
        self._is_scanning = False
        self._base_hashes: Dict[str, str] = {}  # Hashes de referência

    def _load_signatures(self) -> Dict[str, List[bytes]]:
        """Carrega assinaturas de tipos de arquivos conhecidos."""
        return {
            "PE": [b'MZ'],
            "ELF": [b'\x7fELF'],
            "PDF": [b'%PDF'],
            "ZIP": [b'PK\x03\x04'],
            "RAR": [b'Rar!\x1a\x07'],
            "GZIP": [b'\x1f\x8b'],
        }

    def _load_suspicious_patterns(self) -> List[str]:
        """Padrões de nomes suspeitos."""
        return [
            "temp", "tmp", "hidden", "stealth", "backdoor",
            "keylog", "rat", "trojan", "rootkit", "exploit",
            "mining", "crypto", "inject", "hook", "patch",
            "crack", "keygen", "hack", "warez", "pirate"
        ]

    def calculate_hash(self, file_path: str) -> Optional[str]:
        """Calcula o hash SHA-256 de um arquivo."""
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except (IOError, OSError, PermissionError):
            return None

    def _check_file_signature(self, file_path: str) -> Optional[str]:
        """Verifica a assinatura do arquivo (magic bytes)."""
        try:
            with open(file_path, 'rb') as f:
                header = f.read(16)
                for file_type, signatures in self._file_signatures.items():
                    for sig in signatures:
                        if header.startswith(sig):
                            return file_type
            return None
        except (IOError, OSError):
            return None

    def _check_suspicious_name(self, filename: str) -> Tuple[bool, List[str]]:
        """Verifica se o nome do arquivo é suspeito."""
        details = []
        name_lower = filename.lower()

        for pattern in self._suspicious_patterns:
            if pattern in name_lower:
                details.append(f"Nome contém padrão suspeito: '{pattern}'")

        # Verifica caracteres unicode disfarçados
        if any(ord(c) > 127 for c in filename):
            details.append("Nome contém caracteres Unicode não-ASCII")

        # Verifica extensão dupla
        parts = filename.split('.')
        if len(parts) > 2:
            details.append("Arquivo possui extensão dupla (possível disfarce)")

        return len(details) > 0, details

    def _check_file_size(self, size: int) -> Tuple[bool, List[str]]:
        """Verifica se o tamanho do arquivo é anômalo."""
        details = []
        max_size = self.config.get("scanner", "max_file_size_mb") * 1024 * 1024

        if size == 0:
            details.append("Arquivo vazio")
            return True, details
        if size > max_size:
            details.append(f"Arquivo muito grande: {size / (1024*1024):.1f} MB")
            return True, details
        return False, details

    def _check_extension(self, filename: str) -> Tuple[bool, List[str]]:
        """Verifica se a extensão é suspeita."""
        details = []
        ext = Path(filename).suffix.lower()
        suspicious = self.config.get("scanner", "suspicious_extensions", [])
        ignored = self.config.get("scanner", "extensions_to_ignore", [])

        if ext in ignored:
            return False, ["Extensão ignorada pela configuração"]
        if ext in suspicious:
            details.append(f"Extensão suspeita: '{ext}'")
            return True, details
        return False, details

    def scan_file(self, file_path: str) -> Optional[FileScanResult]:
        """Escanea um arquivo individual."""
        try:
            if not os.path.isfile(file_path):
                return None

            stat = os.stat(file_path)
            size = stat.st_size

            # Ignorar arquivos muito grandes
            max_size = self.config.get("scanner", "max_file_size_mb") * 1024 * 1024
            if size > max_size:
                return None

            # Calcular hash
            file_hash = self.calculate_hash(file_path)
            if not file_hash:
                return None

            filename = os.path.basename(file_path)
            all_details = []
            is_suspicious = False

            # Verificações
            name_suspicious, name_details = self._check_suspicious_name(filename)
            all_details.extend(name_details)
            is_suspicious = is_suspicious or name_suspicious

            ext_suspicious, ext_details = self._check_extension(filename)
            all_details.extend(ext_details)
            is_suspicious = is_suspicious or ext_suspicious

            size_suspicious, size_details = self._check_file_size(size)
            all_details.extend(size_details)
            is_suspicious = is_suspicious or size_suspicious

            # Verificar assinatura do arquivo
            signature = self._check_file_signature(file_path)
            if signature:
                all_details.append(f"Tipo identificado: {signature}")
                # Verificar inconsistência extensão/assinatura
                ext = Path(filename).suffix.lower()
                if ext == '.pdf' and signature != 'PDF':
                    all_details.append("INCONSISTÊNCIA: Extensão .pdf mas assinatura diferente!")
                    is_suspicious = True
                elif ext == '.exe' and signature != 'PE':
                    all_details.append("INCONSISTÊNCIA: Extensão .exe mas assinatura diferente!")
                    is_suspicious = True

            # Determinar nível de risco
            risk_level = self._calculate_risk(all_details, is_suspicious)

            return FileScanResult(
                path=file_path,
                name=filename,
                size=size,
                hash_value=file_hash,
                last_modified=datetime.fromtimestamp(stat.st_mtime),
                is_suspicious=is_suspicious,
                risk_level=risk_level,
                details=all_details
            )
        except Exception as e:
            logger.error(f"Erro ao escanear arquivo {file_path}: {e}")
            return None

    def _calculate_risk(self, details: List[str], is_suspicious: bool) -> str:
        """Calcula o nível de risco baseado nos detalhes."""
        critical_keywords = [
            "inconsistência", "backdoor", "rootkit", "trojan",
            "keylog", "rat", "exploit", "inject", "hook"
        ]
        high_keywords = [
            "suspiciosa", "disfarce", "unicode", "extensão dupla",
            "mining", "crypto", "crack", "keygen", "hack"
        ]

        details_text = " ".join(details).lower()

        for kw in critical_keywords:
            if kw in details_text:
                return "critical"

        for kw in high_keywords:
            if kw in details_text:
                return "high"

        if len(details) >= 3:
            return "medium"
        if is_suspicious:
            return "medium"

        return "low"

    def scan_directory(self, directory: str, progress_callback=None) -> Optional[DirectoryScanResult]:
        """Escanea um diretório inteiro recursivamente."""
        with self._scan_lock:
            self._is_scanning = True

        try:
            result = DirectoryScanResult(path=directory)
            start_time = time.time()

            ignore_extensions = set(self.config.get("scanner", "extensions_to_ignore", []))
            max_depth = self.config.get("scanner", "scan_depth", 10)
            max_size = self.config.get("scanner", "max_file_size_mb") * 1024 * 1024

            file_count = 0
            for root, dirs, files in os.walk(directory):
                # Limitar profundidade
                depth = root[len(directory):].count(os.sep)
                if depth >= max_depth:
                    dirs.clear()
                    continue

                for filename in files:
                    filepath = os.path.join(root, filename)
                    ext = Path(filename).suffix.lower()

                    if ext in ignore_extensions:
                        continue

                    try:
                        stat = os.stat(filepath)
                        if stat.st_size > max_size:
                            continue
                    except (OSError, PermissionError):
                        result.errors.append(filepath)
                        continue

                    file_count += 1
                    result.total_files = file_count

                    scan_result = self.scan_file(filepath)
                    if scan_result:
                        result.results.append(scan_result)
                        result.files_scanned += 1
                        if scan_result.is_suspicious:
                            result.suspicious_files += 1

                    if progress_callback and file_count % 100 == 0:
                        progress_callback(
                            file_count, len(files), filename
                        )

            result.scan_duration = time.time() - start_time
            return result

        finally:
            with self._scan_lock:
                self._is_scanning = False

    def scan_specific_paths(self, paths: List[str], progress_callback=None) -> List[FileScanResult]:
        """Escanea caminhos específicos (arquivos ou diretórios)."""
        results = []
        for path in paths:
            if os.path.isfile(path):
                result = self.scan_file(path)
                if result:
                    results.append(result)
            elif os.path.isdir(path):
                dir_result = self.scan_directory(path, progress_callback)
                if dir_result:
                    results.extend(dir_result.results)
        return results

    def detect_altered_files(self, directory: str) -> List[Dict]:
        """Detecta arquivos alterados comparando com hashes anteriores."""
        current_hashes = {}
        for root, dirs, files in os.walk(directory):
            for filename in files:
                filepath = os.path.join(root, filename)
                file_hash = self.calculate_hash(filepath)
                if file_hash:
                    current_hashes[filepath] = file_hash

        altered = []
        for filepath, current_hash in current_hashes.items():
            if filepath in self._base_hashes:
                if current_hash != self._base_hashes[filepath]:
                    altered.append({
                        "path": filepath,
                        "old_hash": self._base_hashes[filepath],
                        "new_hash": current_hash,
                        "detected_at": datetime.now().isoformat()
                    })
            else:
                self._base_hashes[filepath] = current_hash

        return altered

    def detect_encryption_suspicion(self, directory: str) -> List[Dict]:
        """Detecta possíveis atividades de criptografia suspeita (ransomware)."""
        suspicious = []
        recent_files = []
        now = time.time()

        for root, dirs, files in os.walk(directory):
            for filename in files:
                filepath = os.path.join(root, filename)
                try:
                    stat = os.stat(filepath)
                    # Arquivos modificados nos últimos 5 minutos
                    if now - stat.st_mtime < 300:
                        file_hash = self.calculate_hash(filepath)
                        recent_files.append({
                            "path": filepath,
                            "modified": datetime.fromtimestamp(stat.st_mtime),
                            "size": stat.st_size,
                            "hash": file_hash
                        })
                except (OSError, PermissionError):
                    continue

        # Verificar padrões de ransomware
        if len(recent_files) > 10:
            # Muitos arquivos modificados recentemente
            size_changes = sum(1 for f in recent_files if f["size"] != f.get("original_size", f["size"]))
            if size_changes > len(recent_files) * 0.5:
                suspicious.append({
                    "type": "ransomware_pattern",
                    "detail": f"Muitos arquivos alterados recentemente: {len(recent_files)} arquivos nos últimos 5 min",
                    "severity": "critical",
                    "files_affected": len(recent_files)
                })

        # Verificar extensões adicionadas (ex: .encrypted, .locked)
        for rf in recent_files:
            ext = Path(rf["path"]).suffix.lower()
            if ext in ['.encrypted', '.locked', '.crypto', '.crypt', '.locky',
                       '.cryptolocker', '.ransom', '.encoded']:
                suspicious.append({
                    "type": "encryption_extension",
                    "detail": f"Extensão de criptografia detectada: {rf['path']}",
                    "severity": "critical",
                    "path": rf["path"]
                })

        return suspicious

    def get_hash_cache(self) -> Dict[str, str]:
        """Retorna o cache de hashes."""
        return self._hash_cache.copy()

    def set_base_hashes(self, hashes: Dict[str, str]):
        """Define hashes de referência para comparação."""
        self._base_hashes.update(hashes)

    @property
    def is_scanning(self) -> bool:
        return self._is_scanning
