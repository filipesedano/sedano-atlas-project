"""
Scanner de Configuração do Sistema (equivalente ao "Registro" no Linux).
Responsável por: verificar configurações do sistema,
detectar modificações suspeitas, monitorar alterações.
"""

import os
import hashlib
import time
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime

from ..config import config

logger = logging.getLogger("sentinel.scanner.config")


@dataclass
class ConfigChange:
    """Mudança detectada na configuração."""
    file_path: str
    old_hash: Optional[str]
    new_hash: str
    change_type: str  # modified, created, deleted
    severity: str
    detected_at: datetime = field(default_factory=datetime.now)


@dataclass
class SystemConfigResult:
    """Resultado do scan de configuração do sistema."""
    total_files_checked: int
    changes_detected: int
    changes: List[ConfigChange]
    suspicious_modifications: int
    scan_duration: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)


class ConfigScanner:
    """Scanner de configuração do sistema."""

    def __init__(self):
        self.config = config
        self._baseline: Dict[str, str] = {}  # Hashes de referência
        self._baseline_loaded = False
        self._critical_files = self._get_critical_files()
        self._alerts: List[ConfigChange] = []

    def _get_critical_files(self) -> List[str]:
        """Lista de arquivos de configuração críticos."""
        critical = [
            '/etc/passwd',
            '/etc/shadow',
            '/etc/sudoers',
            '/etc/hosts',
            '/etc/ssh/sshd_config',
            '/etc/fstab',
            '/etc/hostname',
            '/etc/resolv.conf',
            '/etc/crontab',
            '/etc/environment',
            '/etc/profile',
            '/etc/bash.bashrc',
            '/etc/ld.so.preload',
            '/etc/hosts.allow',
            '/etc/hosts.deny',
            '/etc/security/access.conf',
        ]

        # Adicionar cron directories
        cron_dirs = ['/etc/cron.d', '/etc/cron.daily', '/etc/cron.hourly',
                     '/etc/cron.weekly', '/etc/cron.monthly']
        for d in cron_dirs:
            if os.path.isdir(d):
                for f in os.listdir(d):
                    fp = os.path.join(d, f)
                    if os.path.isfile(fp):
                        critical.append(fp)

        return critical

    def calculate_hash(self, file_path: str) -> Optional[str]:
        """Calcula hash SHA-256 de um arquivo."""
        try:
            sha256 = hashlib.sha256()
            with open(file_path, 'rb') as f:
                for chunk in iter(lambda: f.read(8192), b''):
                    sha256.update(chunk)
            return sha256.hexdigest()
        except (IOError, OSError, PermissionError):
            return None

    def create_baseline(self) -> int:
        """Cria baseline de hashes para comparação futura."""
        self._baseline.clear()
        files_hashed = 0

        for file_path in self._critical_files:
            if os.path.isfile(file_path):
                file_hash = self.calculate_hash(file_path)
                if file_hash:
                    self._baseline[file_path] = file_hash
                    files_hashed += 1

        self._baseline_loaded = True
        logger.info(f"Baseline criada com {files_hashed} arquivos")
        return files_hashed

    def check_config_changes(self) -> SystemConfigResult:
        """Verifica mudanças na configuração do sistema."""
        start_time = time.time()
        changes = []
        suspicious = 0

        for file_path in self._critical_files:
            if not os.path.isfile(file_path):
                # Arquivo crítico que deveria existir
                if file_path in self._baseline:
                    changes.append(ConfigChange(
                        file_path=file_path,
                        old_hash=self._baseline.get(file_path),
                        new_hash=None,
                        change_type="deleted",
                        severity="critical"
                    ))
                    suspicious += 1
                continue

            current_hash = self.calculate_hash(file_path)
            if not current_hash:
                continue

            if file_path in self._baseline:
                if current_hash != self._baseline[file_path]:
                    severity = self._assess_change_severity(file_path)
                    changes.append(ConfigChange(
                        file_path=file_path,
                        old_hash=self._baseline[file_path],
                        new_hash=current_hash,
                        change_type="modified",
                        severity=severity
                    ))
                    if severity in ["high", "critical"]:
                        suspicious += 1
            else:
                # Novo arquivo em local crítico
                severity = self._assess_change_severity(file_path)
                changes.append(ConfigChange(
                    file_path=file_path,
                    old_hash=None,
                    new_hash=current_hash,
                    change_type="created",
                    severity=severity
                ))

        self._alerts.extend(changes)
        return SystemConfigResult(
            total_files_checked=len(self._critical_files),
            changes_detected=len(changes),
            changes=changes,
            suspicious_modifications=suspicious,
            scan_duration=time.time() - start_time
        )

    def _assess_change_severity(self, file_path: str) -> str:
        """Avalia a severidade de uma mudança."""
        critical_files = ['/etc/shadow', '/etc/sudoers', '/etc/passwd',
                         '/etc/ld.so.preload']
        high_files = ['/etc/hosts', '/etc/ssh/sshd_config', '/etc/fstab',
                      '/etc/resolv.conf', '/etc/crontab']

        for cf in critical_files:
            if cf in file_path:
                return "critical"
        for hf in high_files:
            if hf in file_path:
                return "high"

        return "medium"

    def check_ssh_config(self) -> List[Dict]:
        """Verifica configuração SSH."""
        alerts = []
        ssh_configs = ['/etc/ssh/sshd_config', '/etc/ssh/ssh_config']

        for config_file in ssh_configs:
            if not os.path.isfile(config_file):
                continue
            try:
                with open(config_file, 'r') as f:
                    content = f.read()

                # Verificar PermiteRootLogin yes
                if 'PermitRootLogin yes' in content:
                    alerts.append({
                        "type": "ssh_root_login",
                        "severity": "high",
                        "message": "Login root via SSH permitido",
                        "file": config_file
                    })

                # Verificar PasswordAuthentication yes (sem chave)
                if 'PasswordAuthentication yes' in content and 'PubkeyAuthentication' not in content:
                    alerts.append({
                        "type": "ssh_password_auth",
                        "severity": "medium",
                        "message": "Autenticação por senha habilitada sem chave pública",
                        "file": config_file
                    })

                # Verificar portas não-padrão
                port_match = __import__('re').search(r'^Port\s+(\d+)', content, __import__('re').MULTILINE)
                if port_match:
                    port = int(port_match.group(1))
                    if port != 22:
                        alerts.append({
                            "type": "ssh_nonstandard_port",
                            "severity": "medium",
                            "message": f"SSH rodando em porta não-padrão: {port}",
                            "file": config_file,
                            "port": port
                        })
            except (IOError, PermissionError):
                pass

        return alerts

    def check_user_accounts(self) -> List[Dict]:
        """Verifica contas de usuários do sistema."""
        alerts = []
        try:
            with open('/etc/passwd', 'r') as f:
                for line in f:
                    parts = line.strip().split(':')
                    if len(parts) >= 7:
                        username = parts[0]
                        uid = int(parts[2])
                        shell = parts[6]
                        home = parts[5]

                        # Verificar UID 0 (root) adicional
                        if uid == 0 and username != 'root':
                            alerts.append({
                                "type": "extra_root_account",
                                "severity": "critical",
                                "message": f"Conta com UID 0 (privilegiada) além de root: {username}",
                                "username": username
                            })

                        # Verificar shell suspeito
                        if username != 'root' and shell in ['/bin/sh', '/bin/bash', '/bin/zsh']:
                            # Contas de sistema com shell interativo
                            system_uids = range(0, 1000)
                            if uid in system_uids:
                                alerts.append({
                                    "type": "system_account_shell",
                                    "severity": "low",
                                    "message": f"Conta de sistema com shell interativo: {username}",
                                    "username": username
                                })

                        # Verificar home directory suspeito
                        if username not in ['root', 'daemon', 'bin', 'sys', 'games',
                                          'man', 'lp', 'mail', 'news', 'uucp', 'proxy',
                                          'www-data', 'backup', 'list', 'irc', 'gnats',
                                          'nobody', 'systemd-network', 'systemd-resolve',
                                          'systemd-timesync', 'messagebus', 'syslog',
                                          '_apt', 'tss', 'uuidd', 'tcpdump', 'landscape',
                                          'pollinate', 'usbmux']:
                            if username and not username.startswith('#'):
                                # Conta de usuário com shell
                                if shell and '/bin/shell' not in shell:
                                    pass  # OK
        except (IOError, PermissionError):
            pass

        # Verificar sudoers
        try:
            with open('/etc/sudoers', 'r') as f:
                content = f.read()
                if 'NOPASSWD' in content:
                    alerts.append({
                        "type": "sudo_nopasswd",
                        "severity": "high",
                        "message": "Sudo com NOPASSWD detectado",
                        "file": "/etc/sudoers"
                    })
        except (IOError, PermissionError):
            pass

        return alerts

    def check_file_permissions(self) -> List[Dict]:
        """Verifica permissões de arquivos críticos."""
        alerts = []
        critical_permissions = {
            '/etc/shadow': 0o640,
            '/etc/passwd': 0o644,
            '/etc/sudoers': 0o440,
        }

        for file_path, expected_perm in critical_permissions.items():
            try:
                stat = os.stat(file_path)
                actual_perm = stat.st_mode & 0o777
                if actual_perm != expected_perm:
                    alerts.append({
                        "type": "permission_anomaly",
                        "severity": "high",
                        "message": f"Permissão anômala em {file_path}: {oct(actual_perm)} (esperado: {oct(expected_perm)})",
                        "file": file_path,
                        "actual_permission": oct(actual_perm),
                        "expected_permission": oct(expected_perm)
                    })
            except (IOError, PermissionError):
                pass

        return alerts

    def monitor_config_files(self, callback=None):
        """Monitora alterações em arquivos de configuração."""
        import threading

        def monitor_loop():
            while True:
                try:
                    result = self.check_config_changes()
                    if callback and result.changes:
                        for change in result.changes:
                            if change.severity in ["high", "critical"]:
                                callback(change)
                except Exception as e:
                    logger.error(f"Erro no monitoramento de config: {e}")

                time.sleep(60)  # Verificar a cada minuto

        threading.Thread(target=monitor_loop, daemon=True).start()
        logger.info("Monitoramento de configuração iniciado")

    def get_alerts(self) -> List[ConfigChange]:
        return self._alerts.copy()

    @property
    def baseline_loaded(self) -> bool:
        return self._baseline_loaded
