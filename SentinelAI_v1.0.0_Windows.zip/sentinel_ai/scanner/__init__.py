"""
Módulo Scanner - Unifica todos os scanners do Sentinel AI.
"""

from .file_scanner import FileScanner, FileScanResult, DirectoryScanResult
from .network_scanner import NetworkScanner, ConnectionInfo, NetworkAlert, NetworkScanResult
from .process_scanner import ProcessScanner, ProcessInfo, SystemAlert, SystemScanResult
from .config_scanner import ConfigScanner, ConfigChange, SystemConfigResult

__all__ = [
    'FileScanner', 'FileScanResult', 'DirectoryScanResult',
    'NetworkScanner', 'ConnectionInfo', 'NetworkAlert', 'NetworkScanResult',
    'ProcessScanner', 'ProcessInfo', 'SystemAlert', 'SystemScanResult',
    'ConfigScanner', 'ConfigChange', 'SystemConfigResult',
]
