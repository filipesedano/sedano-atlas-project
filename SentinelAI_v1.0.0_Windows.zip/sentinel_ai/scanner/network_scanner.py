"""
Agente de Rede - Scanner de Rede.
Responsável por: monitorar conexões, detectar tráfego incomum,
verificar IPs e portas suspeitos.
"""

import socket
import threading
import time
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field
from datetime import datetime
from collections import defaultdict

from ..config import config

logger = logging.getLogger("sentinel.scanner.network")


@dataclass
class ConnectionInfo:
    """Informações sobre uma conexão de rede."""
    local_address: str
    local_port: int
    remote_address: str
    remote_port: int
    status: str
    pid: Optional[int] = None
    process_name: Optional[str] = None
    protocol: str = "TCP"
    detected_at: datetime = field(default_factory=datetime.now)


@dataclass
class NetworkAlert:
    """Alerta de rede."""
    alert_type: str
    severity: str  # low, medium, high, critical
    message: str
    details: Dict = field(default_factory=dict)
    timestamp: datetime = field(default_factory=datetime.now)


@dataclass
class NetworkScanResult:
    """Resultado do scan de rede."""
    total_connections: int
    active_connections: List[ConnectionInfo]
    alerts: List[NetworkAlert]
    traffic_summary: Dict = field(default_factory=dict)
    scan_duration: float = 0.0
    completed_at: datetime = field(default_factory=datetime.now)


class NetworkScanner:
    """Scanner de rede do Sentinel AI."""

    def __init__(self):
        self.config = config
        self._connections_history: List[ConnectionInfo] = []
        self._connection_counts: Dict[str, int] = defaultdict(int)
        self._is_monitoring = False
        self._monitor_thread: Optional[threading.Thread] = None
        self._alerts: List[NetworkAlert] = []
        self._known_connections: Dict[str, set] = defaultdict(set)

    def _get_hostname(self, ip: str) -> str:
        """Resolve hostname de um IP."""
        try:
            return socket.gethostbyaddr(ip)[0]
        except (socket.herror, socket.gaierror, socket.timeout):
            return "unknown"

    def _is_private_ip(self, ip: str) -> bool:
        """Verifica se o IP é privado/local."""
        parts = ip.split('.')
        if len(parts) != 4:
            return False
        first = int(parts[0])
        second = int(parts[1])
        if first == 10:
            return True
        if first == 172 and 16 <= second <= 31:
            return True
        if first == 192 and second == 168:
            return True
        if first == 127:
            return True
        if ip == "0.0.0.0":
            return True
        return False

    def _check_port_suspicion(self, port: int) -> Tuple[bool, str]:
        """Verifica se a porta é suspeita."""
        suspicious_ports = self.config.get("network", "suspicious_ports", [])
        if port in suspicious_ports:
            return True, f"Porta suspeita conhecida: {port}"

        # Portas comumente usadas por malware
        malware_ports = {
            4444: "Metasploit default",
            5555: "Android debug / backdoor",
            6666: "IRC backdoor",
            8888: "Alternative HTTP / backdoor",
            1337: "Hacker culture port",
            31337: "Back Orifice / elite",
            12345: "NetBus",
            65535: "Common backdoor port"
        }
        if port in malware_ports:
            return True, f"Porta associada a malware: {port} ({malware_ports[port]})"

        return False, ""

    def scan_connections(self) -> NetworkScanResult:
        """Escanea as conexões de rede atuais."""
        start_time = time.time()
        connections = []
        alerts = []

        try:
            # Usar netstat-like approach
            result = self._get_active_connections()
            connections = result
        except Exception as e:
            logger.error(f"Erro ao obter conexões: {e}")
            alerts.append(NetworkAlert(
                alert_type="scan_error",
                severity="high",
                message=f"Erro ao escanear conexões: {str(e)}"
            ))

        # Analisar cada conexão
        for conn in connections:
            # Verificar portas suspeitas
            local_suspicious, local_msg = self._check_port_suspicion(conn.local_port)
            if local_suspicious:
                alerts.append(NetworkAlert(
                    alert_type="suspicious_port",
                    severity="high",
                    message=local_msg,
                    details={"local_port": conn.local_port, "remote": conn.remote_address}
                ))

            remote_suspicious, remote_msg = self._check_port_suspicion(conn.remote_port)
            if remote_suspicious:
                alerts.append(NetworkAlert(
                    alert_type="suspicious_port",
                    severity="high",
                    message=remote_msg,
                    details={"remote_port": conn.remote_port, "remote": conn.remote_address}
                ))

            # Verificar IP remoto
            if conn.remote_address and not self._is_private_ip(conn.remote_address):
                # Registrar conexão externa
                self._connection_counts[conn.remote_address] += 1

                # Verificar se é um IP conhecido como malicioso
                known_malicious = self.config.get("network", "known_malicious_ips", [])
                if conn.remote_address in known_malicious:
                    alerts.append(NetworkAlert(
                        alert_type="malicious_ip",
                        severity="critical",
                        message=f"Conexão com IP malicioso conhecido: {conn.remote_address}",
                        details={"ip": conn.remote_address}
                    ))

        # Detectar anomalias de volume
        for ip, count in self._connection_counts.items():
            if count > 50 and not self._is_private_ip(ip):
                alerts.append(NetworkAlert(
                    alert_type="connection_flood",
                    severity="high",
                    message=f"Alto volume de conexões para {ip}: {count} conexões",
                    details={"ip": ip, "count": count}
                ))

        # Armazenar histórico
        self._connections_history.extend(connections)
        self._alerts.extend(alerts)

        # Limpar histórico se muito grande
        if len(self._connections_history) > 10000:
            self._connections_history = self._connections_history[-5000:]

        return NetworkScanResult(
            total_connections=len(connections),
            active_connections=connections,
            alerts=alerts,
            traffic_summary=dict(self._connection_counts),
            scan_duration=time.time() - start_time
        )

    def _get_active_connections(self) -> List[ConnectionInfo]:
        """Obtém conexões ativas via /proc/net."""
        connections = []
        try:
            # Tentar ler /proc/net/tcp
            with open('/proc/net/tcp', 'r') as f:
                lines = f.readlines()[1:]  # Pular header
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        conn = self._parse_proc_entry(parts, "TCP")
                        if conn:
                            connections.append(conn)

            # Tentar ler /proc/net/tcp6
            with open('/proc/net/tcp6', 'r') as f:
                lines = f.readlines()[1:]
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 4:
                        conn = self._parse_proc6_entry(parts, "TCP6")
                        if conn:
                            connections.append(conn)
        except (IOError, PermissionError):
            # Fallback: usar socket
            connections = self._get_connections_socket()

        return connections

    def _parse_proc_entry(self, parts: List[str], protocol: str) -> Optional[ConnectionInfo]:
        """Parseia uma entrada de /proc/net/tcp."""
        try:
            local_hex = parts[1]
            remote_hex = parts[2]
            status_hex = parts[3]

            local_addr = self._decode_hex_addr(local_hex)
            remote_addr = self._decode_hex_addr(remote_hex)
            status = self._decode_tcp_status(status_hex)

            return ConnectionInfo(
                local_address=local_addr[0],
                local_port=local_addr[1],
                remote_address=remote_addr[0],
                remote_port=remote_addr[1],
                status=status,
                protocol=protocol
            )
        except Exception:
            return None

    def _parse_proc6_entry(self, parts: List[str], protocol: str) -> Optional[ConnectionInfo]:
        """Parseia uma entrada de /proc/net/tcp6."""
        try:
            local_hex = parts[1]
            remote_hex = parts[2]
            status_hex = parts[3]

            local_addr = self._decode_hex_addr6(local_hex)
            remote_addr = self._decode_hex_addr6(remote_hex)
            status = self._decode_tcp_status(status_hex)

            return ConnectionInfo(
                local_address=local_addr[0],
                local_port=local_addr[1],
                remote_address=remote_addr[0],
                remote_port=remote_addr[1],
                status=status,
                protocol=protocol
            )
        except Exception:
            return None

    def _decode_hex_addr(self, hex_addr: str) -> Tuple[str, int]:
        """Decodifica endereço hexadecimal (IPv4)."""
        parts = hex_addr.split(':')
        ip_hex = parts[0]
        port_hex = parts[1]

        # Convert little-endian hex to IP
        ip_bytes = bytes.fromhex(ip_hex)
        ip = f"{ip_bytes[3]}.{ip_bytes[2]}.{ip_bytes[1]}.{ip_bytes[0]}"
        port = int(port_hex, 16)

        return (ip, port)

    def _decode_hex_addr6(self, hex_addr: str) -> Tuple[str, int]:
        """Decodifica endereço hexadecimal (IPv6)."""
        parts = hex_addr.split(':')
        ip_hex = parts[0]
        port_hex = parts[1]

        # Simplified: just return as hex for IPv6
        ip = ip_hex  # Full hex representation
        port = int(port_hex, 16)

        return (ip, port)

    def _decode_tcp_status(self, status_hex: str) -> str:
        """Decodifica status TCP."""
        statuses = {
            '01': 'ESTABLISHED',
            '02': 'SYN_SENT',
            '03': 'SYN_RECV',
            '04': 'FIN_WAIT1',
            '05': 'FIN_WAIT2',
            '06': 'TIME_WAIT',
            '07': 'CLOSE',
            '08': 'CLOSE_WAIT',
            '09': 'LAST_ACK',
            '0A': 'LISTEN',
            '0B': 'CLOSING',
        }
        return statuses.get(status_hex.upper(), f"UNKNOWN({status_hex})")

    def _get_connections_socket(self) -> List[ConnectionInfo]:
        """Fallback: obtém conexões via socket."""
        connections = []
        try:
            result = socket.getaddrinfo(socket.gethostname(), None)
            # This is limited, just returns local info
            connections.append(ConnectionInfo(
                local_address=socket.gethostbyname(socket.gethostname()),
                local_port=0,
                remote_address="0.0.0.0",
                remote_port=0,
                status="UNKNOWN",
                protocol="TCP"
            ))
        except Exception:
            pass
        return connections

    def check_dns_anomalies(self) -> List[NetworkAlert]:
        """Verifica anomalias DNS."""
        alerts = []
        try:
            with open('/etc/resolv.conf', 'r') as f:
                for line in f:
                    if line.strip().startswith('nameserver'):
                        ns = line.strip().split()[1]
                        # Verificar se o DNS é suspeito
                        if not self._is_private_ip(ns) and ns not in [
                            '8.8.8.8', '8.8.4.4', '1.1.1.1', '1.0.0.1',
                            '9.9.9.9', '208.67.222.222', '208.67.220.220'
                        ]:
                            alerts.append(NetworkAlert(
                                alert_type="dns_anomaly",
                                severity="medium",
                                message=f"DNS não-padronizado detectado: {ns}",
                                details={"dns_server": ns}
                            ))
        except (IOError, PermissionError):
            pass

        # Verificar hosts file
        try:
            with open('/etc/hosts', 'r') as f:
                lines = f.readlines()
                suspicious_entries = [l for l in lines if
                                     not l.strip().startswith('#') and
                                     l.strip() and
                                     'localhost' not in l.lower()]
                if len(suspicious_entries) > 3:
                    alerts.append(NetworkAlert(
                        alert_type="hosts_file_anomaly",
                        severity="high",
                        message=f"Arquivo hosts contém {len(suspicious_entries)} entradas suspeitas",
                        details={"entries": [l.strip() for l in suspicious_entries]}
                    ))
        except (IOError, PermissionError):
            pass

        return alerts

    def check_open_ports(self) -> List[NetworkAlert]:
        """Verifica portas abertas locais."""
        alerts = []
        try:
            # Ler /proc/net/tcp para portas em LISTEN
            with open('/proc/net/tcp', 'r') as f:
                lines = f.readlines()[1:]
                for line in lines:
                    parts = line.strip().split()
                    if len(parts) >= 4 and parts[3].upper() == '0A':  # LISTEN
                        local_hex = parts[1]
                        port = int(local_hex.split(':')[1], 16)

                        if port < 1024:  # Portas privilegiadas
                            suspicious_ports = [
                                21, 22, 23, 25, 53, 80, 110, 143, 443,
                                993, 995, 3306, 3389, 5432, 5900, 8080
                            ]
                            if port in suspicious_ports:
                                alerts.append(NetworkAlert(
                                    alert_type="open_port",
                                    severity="medium",
                                    message=f"Porta {port} aberta (LISTEN)",
                                    details={"port": port}
                                ))
        except (IOError, PermissionError):
            pass

        return alerts

    def start_monitoring(self, callback=None):
        """Inicia monitoramento contínuo da rede."""
        self._is_monitoring = True

        def monitor_loop():
            while self._is_monitoring:
                try:
                    result = self.scan_connections()
                    if callback and result.alerts:
                        for alert in result.alerts:
                            callback(alert)
                except Exception as e:
                    logger.error(f"Erro no monitoramento de rede: {e}")
                time.sleep(self.config.get("network", "monitor_interval_seconds", 10))

        self._monitor_thread = threading.Thread(target=monitor_loop, daemon=True)
        self._monitor_thread.start()
        logger.info("Monitoramento de rede iniciado")

    def stop_monitoring(self):
        """Para o monitoramento de rede."""
        self._is_monitoring = False
        if self._monitor_thread:
            self._monitor_thread.join(timeout=15)
        logger.info("Monitoramento de rede parado")

    def get_alerts(self) -> List[NetworkAlert]:
        """Retorna todos os alertas de rede."""
        return self._alerts.copy()

    def clear_alerts(self):
        """Limpa os alertas de rede."""
        self._alerts.clear()

    @property
    def is_monitoring(self) -> bool:
        return self._is_monitoring
