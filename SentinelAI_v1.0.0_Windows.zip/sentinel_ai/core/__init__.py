"""Módulo Core - Engine principal."""
from .engine import SentinelEngine, EngineStatus
__all__ = ['SentinelEngine', 'EngineStatus']
