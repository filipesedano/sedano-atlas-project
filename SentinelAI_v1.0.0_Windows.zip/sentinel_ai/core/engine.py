"""
Agente Principal (Engine) do Sentinel AI.
Coordena todos os agentes, executa scans, integra com IA analista
e gerencia o ciclo de vida do sistema.
"""

import os
import sys
import time
import threading
import logging
import signal
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field
from datetime import datetime

from ..config import config
from ..agents.file_agent import FileAgent, FileAgentReport
from ..agents.network_agent import NetworkAgent, NetworkAgentReport
from ..agents.log_agent import LogAgent, LogAgentReport
from ..agents.process_agent import ProcessAgent, ProcessAgentReport
from ..agents.ai_agent import AIAgent, ComprehensiveReport
from ..database.db_manager import DatabaseManager

logger = logging.getLogger("sentinel.engine")


@dataclass
class EngineStatus:
    """Status atual do engine."""
    is_running: bool
    current_task: str
    last_scan_time: Optional[datetime]
    scans_completed: int
    threats_detected: int
    system_risk_score: float
    uptime: float
    timestamp: datetime = field(default_factory=datetime.now)


class SentinelEngine:
    """Engine principal do Sentinel AI."""

    def __init__(self):
        self.config = config
        self._is_running = False
        self._start_time = None
        self._scan_count = 0
        self._threat_count = 0
        self._current_task = "idle"
        self._callbacks: Dict[str, List[Callable]] = {}
        self._monitor_threads: List[threading.Thread] = []

        # Inicializar banco de dados
        self.db = DatabaseManager()
        self.db.initialize()

        # Inicializar agentes
        self.file_agent = FileAgent(db_manager=self.db)
        self.network_agent = NetworkAgent(db_manager=self.db)
        self.log_agent = LogAgent(db_manager=self.db)
        self.process_agent = ProcessAgent(db_manager=self.db)
        self.ai_agent = AIAgent()

        # Últimos resultados
        self._last_reports: Dict[str, Dict] = {}
        self._last_comprehensive: Optional[ComprehensiveReport] = None

        logger.info("Sentinel AI Engine inicializado")

    def initialize(self):
        """Inicializa o engine e seus componentes."""
        logger.info("Inicializando componentes do Sentinel AI")

        # Criar diretórios necessários
        os.makedirs(self.config.get("ui", "window_title", "").split(" - ")[0].lower().replace(" ", "_"),
                    exist_ok=True)

        # Verificar configuração
        if not self.config.get("scanner", "hash_algorithm"):
            logger.warning("Algoritmo de hash não configurado")

        # Registrar no banco
        self.db.save_event("system", "startup", "info",
                          "Sentinel AI Engine iniciado")

        logger.info("Sentinel AI Engine pronto")

    def start(self):
        """Inicia o engine principal."""
        if self._is_running:
            logger.warning("Engine já está rodando")
            return

        self._is_running = True
        self._start_time = time.time()
        self._current_task = "initializing"

        logger.info("Sentinel AI Engine iniciado")
        self._notify("engine_started", {"timestamp": datetime.now().isoformat()})

    def stop(self):
        """Para o engine."""
        self._is_running = False
        self._current_task = "stopped"

        # Parar monitoramentos
        self.network_agent.stop_monitoring()
        self.process_agent.stop_monitoring()

        logger.info("Sentinel AI Engine parado")
        self._notify("engine_stopped", {"timestamp": datetime.now().isoformat()})

    def full_scan(self, target_path: str = "/", progress_callback: Callable = None) -> ComprehensiveReport:
        """Executa scan completo do sistema."""
        self._current_task = "full_scan"
        logger.info("Iniciando scan completo do sistema")
        self._notify("scan_started", {"type": "full", "target": target_path})

        reports = {}

        # 1. Scan de arquivos
        if target_path and os.path.exists(target_path):
            logger.info("Fase 1/4: Scanner de arquivos")
            file_report = self.file_agent.full_scan(target_path, progress_callback)
            reports["file"] = file_report
        else:
            file_report = self.file_agent.quick_scan()
            reports["file"] = file_report

        # 2. Scan de rede
        logger.info("Fase 2/4: Scanner de rede")
        network_report = self.network_agent.full_scan()
        reports["network"] = network_report

        # 3. Scan de processos
        logger.info("Fase 3/4: Scanner de processos")
        process_report = self.process_agent.full_scan()
        reports["process"] = process_report

        # 4. Análise de logs
        logger.info("Fase 4/4: Análise de logs")
        log_report = self.log_agent.scan_system_logs()
        reports["log"] = log_report

        # Análise da IA
        logger.info("Analisando resultados com IA")
        comprehensive = self.ai_agent.analyze_all_data(
            file_report=dataclass_to_dict(reports["file"]),
            network_report=dataclass_to_dict(reports["network"]),
            log_report=dataclass_to_dict(reports["log"]),
            process_report=dataclass_to_dict(reports["process"])
        )

        self._last_comprehensive = comprehensive
        self._last_reports = reports
        self._scan_count += 1
        self._threat_count += comprehensive.threat_count

        # Salvar no banco
        self.db.save_scan_result("comprehensive", comprehensive)

        self._current_task = "idle"
        self._notify("scan_completed", {
            "risk_score": comprehensive.overall_risk_score,
            "threats": comprehensive.threat_count,
            "timestamp": datetime.now().isoformat()
        })

        logger.info(f"Scan completo finalizado. Risco: {comprehensive.overall_risk_score:.1f}%, "
                     f"Ameaças: {comprehensive.threat_count}")
        return comprehensive

    def quick_scan(self) -> ComprehensiveReport:
        """Executa scan rápido."""
        self._current_task = "quick_scan"
        logger.info("Iniciando scan rápido")

        file_report = self.file_agent.quick_scan()
        network_report = self.network_agent.full_scan()
        process_report = self.process_agent.full_scan()

        comprehensive = self.ai_agent.analyze_all_data(
            file_report=dataclass_to_dict(file_report),
            network_report=dataclass_to_dict(network_report),
            process_report=dataclass_to_dict(process_report)
        )

        self._last_comprehensive = comprehensive
        self._scan_count += 1
        self._threat_count += comprehensive.threat_count

        self.db.save_scan_result("quick_scan", comprehensive)
        self._current_task = "idle"

        logger.info(f"Scan rápido finalizado. Risco: {comprehensive.overall_risk_score:.1f}%")
        return comprehensive

    def start_real_time_monitoring(self):
        """Inicia monitoramento em tempo real."""
        logger.info("Iniciando monitoramento em tempo real")

        # Monitoramento de rede
        def network_callback(alert):
            self._notify("network_alert", {
                "type": alert.alert_type,
                "severity": alert.severity,
                "message": alert.message
            })

        self.network_agent.start_monitoring(callback=network_callback)

        # Monitoramento de processos
        def process_callback(proc_info):
            self._notify("process_alert", {
                "name": proc_info.name,
                "pid": proc_info.pid,
                "suspicious": proc_info.is_suspicious,
                "details": proc_info.details
            })

        self.process_agent.start_monitoring(callback=process_callback)

        self._notify("monitoring_started", {"timestamp": datetime.now().isoformat()})
        logger.info("Monitoramento em tempo real ativo")

    def stop_real_time_monitoring(self):
        """Para monitoramento em tempo real."""
        self.network_agent.stop_monitoring()
        self.process_agent.stop_monitoring()
        self._notify("monitoring_stopped", {"timestamp": datetime.now().isoformat()})
        logger.info("Monitoramento em tempo real parado")

    def get_status(self) -> EngineStatus:
        """Retorna status atual do engine."""
        uptime = time.time() - self._start_time if self._start_time else 0

        risk_score = 0
        if self._last_comprehensive:
            risk_score = self._last_comprehensive.overall_risk_score

        return EngineStatus(
            is_running=self._is_running,
            current_task=self._current_task,
            last_scan_time=self._last_comprehensive.timestamp if self._last_comprehensive else None,
            scans_completed=self._scan_count,
            threats_detected=self._threat_count,
            system_risk_score=risk_score,
            uptime=uptime
        )

    def get_last_report(self) -> Optional[ComprehensiveReport]:
        """Retorna o último relatório abrangente."""
        return self._last_comprehensive

    def get_all_reports(self) -> Dict:
        """Retorna todos os últimos relatórios."""
        return self._last_reports.copy()

    def register_callback(self, event_type: str, callback: Callable):
        """Registra callback para eventos."""
        if event_type not in self._callbacks:
            self._callbacks[event_type] = []
        self._callbacks[event_type].append(callback)

    def _notify(self, event_type: str, data: Dict):
        """Notifica callbacks registrados."""
        if event_type in self._callbacks:
            for callback in self._callbacks[event_type]:
                try:
                    callback(data)
                except Exception as e:
                    logger.error(f"Erro no callback {event_type}: {e}")

    def get_learning_data(self) -> List[Dict]:
        """Retorna dados de aprendizado da IA."""
        return self.ai_agent._learning_data

    def provide_feedback(self, threat: str, was_false_positive: bool):
        """Fornece feedback à IA."""
        self.ai_agent.learn_from_feedback(threat, was_false_positive)

    @property
    def is_running(self) -> bool:
        return self._is_running


def dataclass_to_dict(obj) -> Dict:
    """Converte dataclass para dicionário."""
    if hasattr(obj, '__dataclass_fields__'):
        result = {}
        for field_name in obj.__dataclass_fields__:
            value = getattr(obj, field_name)
            if hasattr(value, '__dataclass_fields__'):
                result[field_name] = dataclass_to_dict(value)
            elif isinstance(value, list):
                result[field_name] = [
                    dataclass_to_dict(item) if hasattr(item, '__dataclass_fields__')
                    else item for item in value
                ]
            elif isinstance(value, dict):
                result[field_name] = {
                    k: dataclass_to_dict(v) if hasattr(v, '__dataclass_fields__')
                    else v for k, v in value.items()
                }
            elif isinstance(value, datetime):
                result[field_name] = value.isoformat()
            else:
                result[field_name] = value
        return result
    return obj
