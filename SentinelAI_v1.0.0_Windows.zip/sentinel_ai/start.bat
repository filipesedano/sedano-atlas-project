@echo off
title Sentinel AI
color 0A
cls
echo.
echo ============================================================
echo   SENTINEL AI - Sistema de Segurança Inteligente
echo ============================================================
echo.
echo Verificando Python...
python --version >nul 2>&1
if errorlevel 1 (
    echo.
    echo [ERRO] Python nao encontrado!
    echo.
    echo Baixe Python em: https://www.python.org/downloads/
    echo IMPORTANTE: Marque "Add Python to PATH" durante instalacao.
    echo.
    pause
    exit /b 1
)

echo [OK] Python encontrado.
echo Instalando dependencias...
python -m pip install customtkinter --quiet --user
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao instalar dependencias.
    echo Tente: pip install customtkinter
    echo.
    pause
    exit /b 1
)

echo.
echo Iniciando Sentinel AI...
echo.
python -m sentinel_ai.main --gui
if errorlevel 1 (
    echo.
    echo [ERRO] Falha ao iniciar. Tentando modo CLI...
    python -m sentinel_ai.main --cli status
)
echo.
pause
