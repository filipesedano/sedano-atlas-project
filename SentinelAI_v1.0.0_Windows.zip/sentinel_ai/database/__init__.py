"""Módulo de Banco de Dados."""
from .db_manager import DatabaseManager
__all__ = ['DatabaseManager']
