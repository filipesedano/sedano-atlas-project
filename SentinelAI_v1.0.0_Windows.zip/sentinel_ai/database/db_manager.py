"""
Gerenciador de Banco de Dados do Sentinel AI.
Usa SQLite com suporte a criptografia.
"""

import os
import json
import sqlite3
import logging
import threading
from typing import Dict, List, Optional, Any
from datetime import datetime
from contextlib import contextmanager

from ..config import config, DATA_DIR

logger = logging.getLogger("sentinel.database")


class DatabaseManager:
    """Gerencia o banco de dados SQLite do Sentinel AI."""

    def __init__(self):
        self.config = config
        self.db_path = DATA_DIR / "sentinel_ai.db"
        self._lock = threading.Lock()
        self._initialized = False

    def initialize(self):
        """Inicializa o banco de dados."""
        if self._initialized:
            return

        # Criar diretório
        os.makedirs(DATA_DIR, exist_ok=True)

        with self._lock:
            conn = sqlite3.connect(str(self.db_path))
            cursor = conn.cursor()

            # Tabela de scans
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS scans (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    scan_type TEXT NOT NULL,
                    timestamp TEXT NOT NULL,
                    risk_score REAL,
                    threat_count INTEGER,
                    summary TEXT,
                    data TEXT,
                    duration REAL
                )
            ''')

            # Tabela de alertas
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    alert_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    message TEXT,
                    source TEXT,
                    timestamp TEXT NOT NULL,
                    details TEXT
                )
            ''')

            # Tabela de eventos
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_type TEXT NOT NULL,
                    source TEXT,
                    severity TEXT,
                    message TEXT,
                    timestamp TEXT NOT NULL,
                    data TEXT
                )
            ''')

            # Tabela de histórico de ameaças
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS threat_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    threat_type TEXT NOT NULL,
                    probability REAL,
                    risk_level TEXT,
                    description TEXT,
                    evidence TEXT,
                    resolved INTEGER DEFAULT 0,
                    timestamp TEXT NOT NULL
                )
            ''')

            # Tabela de configurações
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS config_entries (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    key TEXT UNIQUE NOT NULL,
                    value TEXT,
                    section TEXT,
                    updated_at TEXT NOT NULL
                )
            ''')

            # Tabela de baseline de arquivos
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS file_baseline (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    file_path TEXT NOT NULL,
                    hash_value TEXT NOT NULL,
                    file_size INTEGER,
                    recorded_at TEXT NOT NULL,
                    UNIQUE(file_path)
                )
            ''')

            # Indices
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_scans_timestamp ON scans(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_alerts_severity ON alerts(severity)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_alerts_timestamp ON alerts(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_events_timestamp ON events(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_threats_timestamp ON threat_history(timestamp)')
            cursor.execute('CREATE INDEX IF NOT EXISTS idx_baseline_path ON file_baseline(file_path)')

            conn.commit()
            conn.close()

        self._initialized = True
        logger.info(f"Banco de dados inicializado: {self.db_path}")

    @contextmanager
    def get_connection(self):
        """Context manager para conexões seguras."""
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        try:
            yield conn
            conn.commit()
        except Exception as e:
            conn.rollback()
            logger.error(f"Erro no banco de dados: {e}")
            raise
        finally:
            conn.close()

    def save_scan_result(self, scan_type: str, report: Any):
        """Salva resultado de scan no banco."""
        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                data = json.dumps(self._serialize(report), default=str)

                risk_score = getattr(report, 'risk_score', getattr(report, 'overall_risk_score', 0))
                threat_count = getattr(report, 'threat_count', 0)
                summary = getattr(report, 'summary', '')
                duration = getattr(report, 'scan_duration', 0)

                cursor.execute('''
                    INSERT INTO scans (scan_type, timestamp, risk_score, threat_count, summary, data, duration)
                    VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    scan_type,
                    datetime.now().isoformat(),
                    risk_score,
                    threat_count,
                    summary[:500] if summary else '',
                    data,
                    duration
                ))

    def save_alert(self, source: str, alert_type: str, severity: str, message: str, details: Dict = None):
        """Salva um alerta no banco."""
        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO alerts (alert_type, severity, message, source, timestamp, details)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    alert_type,
                    severity,
                    message[:500] if message else '',
                    source,
                    datetime.now().isoformat(),
                    json.dumps(details, default=str) if details else ''
                ))

    def save_event(self, source: str, event_type: str, severity: str, message: str, data: Dict = None):
        """Salva um evento no banco."""
        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO events (event_type, source, severity, message, timestamp, data)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    event_type,
                    source,
                    severity,
                    message[:500] if message else '',
                    datetime.now().isoformat(),
                    json.dumps(data, default=str) if data else ''
                ))

    def save_threat(self, threat_type: str, probability: float, risk_level: str,
                    description: str, evidence: List[str] = None):
        """Salva uma ameaça detectada no banco."""
        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('''
                    INSERT INTO threat_history (threat_type, probability, risk_level, description, evidence, timestamp)
                    VALUES (?, ?, ?, ?, ?, ?)
                ''', (
                    threat_type,
                    probability,
                    risk_level,
                    description[:500] if description else '',
                    json.dumps(evidence, default=str) if evidence else '[]',
                    datetime.now().isoformat()
                ))

    def get_scan_history(self, scan_type: str = None, limit: int = 100) -> List[Dict]:
        """Obtém histórico de scans."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if scan_type:
                cursor.execute('''
                    SELECT * FROM scans WHERE scan_type = ?
                    ORDER BY timestamp DESC LIMIT ?
                ''', (scan_type, limit))
            else:
                cursor.execute('''
                    SELECT * FROM scans ORDER BY timestamp DESC LIMIT ?
                ''', (limit,))

            return [dict(row) for row in cursor.fetchall()]

    def get_alerts(self, severity: str = None, limit: int = 100) -> List[Dict]:
        """Obtém alertas do banco."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            if severity:
                cursor.execute('''
                    SELECT * FROM alerts WHERE severity = ?
                    ORDER BY timestamp DESC LIMIT ?
                ''', (severity, limit))
            else:
                cursor.execute('''
                    SELECT * FROM alerts ORDER BY timestamp DESC LIMIT ?
                ''', (limit,))

            return [dict(row) for row in cursor.fetchall()]

    def get_events(self, limit: int = 100) -> List[Dict]:
        """Obtém eventos do banco."""
        with self.get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                SELECT * FROM events ORDER BY timestamp DESC LIMIT ?
            ''', (limit,))
            return [dict(row) for row in cursor.fetchall()]

    def get_statistics(self) -> Dict:
        """Obtém estatísticas gerais."""
        with self.get_connection() as conn:
            cursor = conn.cursor()

            cursor.execute('SELECT COUNT(*) FROM scans')
            total_scans = cursor.fetchone()[0]

            cursor.execute('SELECT COUNT(*) FROM alerts WHERE severity IN (?, ?)',
                           ('critical', 'high'))
            critical_alerts = cursor.fetchone()[0]

            cursor.execute('SELECT COUNT(*) FROM threat_history WHERE resolved = 0')
            open_threats = cursor.fetchone()[0]

            cursor.execute('SELECT AVG(risk_score) FROM scans')
            avg_risk = cursor.fetchone()[0] or 0

            cursor.execute('''
                SELECT scan_type, COUNT(*) as count
                FROM scans GROUP BY scan_type ORDER BY count DESC
            ''')
            scan_types = {row['scan_type']: row['count'] for row in cursor.fetchall()}

            return {
                "total_scans": total_scans,
                "critical_alerts": critical_alerts,
                "open_threats": open_threats,
                "average_risk_score": round(avg_risk, 2),
                "scan_type_counts": scan_types,
                "database_size": os.path.getsize(self.db_path) if self.db_path.exists() else 0
            }

    def resolve_threat(self, threat_id: int):
        """Marca uma ameaça como resolvida."""
        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(
                    'UPDATE threat_history SET resolved = 1 WHERE id = ?',
                    (threat_id,)
                )

    def cleanup_old_data(self, days: int = 30):
        """Limpa dados antigos."""
        cutoff = (datetime.now() - __import__('datetime').timedelta(days=days)).isoformat()

        with self._lock:
            with self.get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute('DELETE FROM alerts WHERE timestamp < ?', (cutoff,))
                cursor.execute('DELETE FROM events WHERE timestamp < ?', (cutoff,))
                logger.info(f"Limpeza: dados anteriores a {cutoff} removidos")

    def _serialize(self, obj: Any) -> Any:
        """Serializa objetos para JSON."""
        if hasattr(obj, '__dataclass_fields__'):
            result = {}
            for field_name in obj.__dataclass_fields__:
                value = getattr(obj, field_name)
                result[field_name] = self._serialize(value)
            return result
        elif isinstance(obj, (list, tuple)):
            return [self._serialize(item) for item in obj]
        elif isinstance(obj, dict):
            return {k: self._serialize(v) for k, v in obj.items()}
        elif isinstance(obj, datetime):
            return obj.isoformat()
        elif hasattr(obj, 'isoformat'):
            return obj.isoformat()
        else:
            return obj
