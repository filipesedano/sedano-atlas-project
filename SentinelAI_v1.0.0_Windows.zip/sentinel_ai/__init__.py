"""Sentinel AI - Sistema de Segurança Inteligente"""
__version__ = "1.0.0"
