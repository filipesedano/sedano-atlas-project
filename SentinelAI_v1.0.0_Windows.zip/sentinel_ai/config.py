"""
Configuração central do Projeto Sentinel AI.
"""

import os
import json
from pathlib import Path


# Diretório base do projeto
BASE_DIR = Path(__file__).parent

# Diretório de dados
DATA_DIR = BASE_DIR / "data"
DATA_DIR.mkdir(exist_ok=True)

# Banco de dados
DB_PATH = DATA_DIR / "sentinel_ai.db"
DB_ENCRYPTED_PATH = DATA_DIR / "sentinel_ai_encrypted.db"

# Configuração de criptografia
ENCRYPTION_KEY_FILE = DATA_DIR / "encryption_key.key"
ENCRYPTION_ALGORITHM = "AES-256-GCM"

# Configuração do Scanner
SCANNER_CONFIG = {
    "max_file_size_mb": 100,           # Tamanho máximo de arquivo para escanear
    "scan_depth": 10,                  # Profundidade máxima de diretórios
    "extensions_to_ignore": [          # Extensões ignoradas por padrão
        ".tmp", ".log", ".bak", ".swp",
        ".DS_Store", "thumbs.db"
    ],
    "hash_algorithm": "SHA-256",
    "scan_interval_seconds": 300,      # Intervalo entre scans automáticos
    "suspicious_extensions": [         # Extensões suspeitas
        ".exe", ".bat", ".cmd", ".ps1", ".vbs", ".js",
        ".hta", ".wsf", ".scr", ".pif", ".com", ".msi",
        ".dll", ".sys", ".drv", ".inf"
    ]
}

# Configuração do Agente de Rede
NETWORK_CONFIG = {
    "monitor_interval_seconds": 10,
    "max_connections_tracked": 1000,
    "suspicious_ports": [4444, 5555, 6666, 7777, 8888, 1337, 31337],
    "tor_exit_nodes": [],              # Carregado dinamicamente
    "known_malicious_ips": [],         # Carregado dinamicamente
}

# Configuração do Agente de Logs
LOG_CONFIG = {
    "max_events_to_analyze": 1000,
    "event_types": [
        "security", "system", "application",
        "powershell", "network"
    ],
    "correlation_window_minutes": 30,
}

# Configuração da IA
AI_CONFIG = {
    "model": "default",
    "confidence_threshold": 0.7,       # Limiar de confiança para alertas
    "max_history_entries": 10000,      # Máximo de entradas no histórico
    "learning_enabled": True,          # Habilitar aprendizado
}

# Configuração da Interface
UI_CONFIG = {
    "theme": "dark",                   # "dark" ou "light"
    "refresh_interval_ms": 2000,       # Intervalo de atualização da UI
    "show_notifications": True,
    "window_title": "Sentinel AI - Sistema de Segurança",
    "window_size": "1200x800",
}

# Configuração de criptografia
CRYPTO_CONFIG = {
    "algorithm": "AES-256-GCM",
    "key_length": 32,
    "salt_length": 16,
}


class SentinelConfig:
    """Gerenciador central de configuração."""

    def __init__(self):
        self._config = {
            "scanner": SCANNER_CONFIG,
            "network": NETWORK_CONFIG,
            "logs": LOG_CONFIG,
            "ai": AI_CONFIG,
            "ui": UI_CONFIG,
            "crypto": CRYPTO_CONFIG,
        }
        self._config_file = DATA_DIR / "sentinel_config.json"
        self._load_custom_config()

    def _load_custom_config(self):
        """Carrega configuração personalizada se existir."""
        if self._config_file.exists():
            try:
                with open(self._config_file, 'r', encoding='utf-8') as f:
                    custom = json.load(f)
                    self._config.update(custom)
            except (json.JSONDecodeError, IOError):
                pass

    def save_config(self):
        """Salva a configuração atual."""
        with open(self._config_file, 'w', encoding='utf-8') as f:
            json.dump(self._config, f, indent=2, default=str)

    def get(self, section: str, key: str = None, default=None):
        """Obtém uma configuração."""
        section_config = self._config.get(section, {})
        if key:
            return section_config.get(key, default)
        return section_config

    def set(self, section: str, key: str, value):
        """Define uma configuração."""
        if section not in self._config:
            self._config[section] = {}
        self._config[section][key] = value
        self.save_config()

    @property
    def all_config(self):
        return self._config.copy()


# Instância global
config = SentinelConfig()
