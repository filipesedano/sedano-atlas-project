"""Módulo de Utilitários."""
