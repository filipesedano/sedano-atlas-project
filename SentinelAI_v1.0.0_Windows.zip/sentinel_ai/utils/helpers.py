"""
Utilitários do Sentinel AI.
"""

import os
import time
import hashlib
import socket
import subprocess
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from pathlib import Path

logger = logging.getLogger("sentinel.utils")


def format_size(bytes_size: int) -> str:
    """Formata tamanho em bytes para formato legível."""
    for unit in ['B', 'KB', 'MB', 'GB', 'TB']:
        if bytes_size < 1024:
            return f"{bytes_size:.1f} {unit}"
        bytes_size /= 1024
    return f"{bytes_size:.1f} PB"


def format_duration(seconds: float) -> str:
    """Formata duração em formato legível."""
    if seconds < 60:
        return f"{seconds:.1f}s"
    elif seconds < 3600:
        mins = int(seconds // 60)
        secs = seconds % 60
        return f"{mins}m {secs:.1f}s"
    else:
        hours = int(seconds // 3600)
        mins = int((seconds % 3600) // 60)
        return f"{hours}h {mins}m"


def format_timestamp(dt: datetime) -> str:
    """Formata timestamp para exibição."""
    return dt.strftime("%d/%m/%Y %H:%M:%S")


def format_relative_time(dt: datetime) -> str:
    """Formata tempo relativo."""
    now = datetime.now()
    diff = (now - dt).total_seconds()

    if diff < 60:
        return "agora"
    elif diff < 3600:
        return f"{int(diff // 60)} min atrás"
    elif diff < 86400:
        return f"{int(diff // 3600)} h atrás"
    else:
        return f"{int(diff // 86400)} dias atrás"


def get_system_info() -> Dict:
    """Obtém informações do sistema."""
    info = {}

    # Hostname
    try:
        info["hostname"] = socket.gethostname()
    except Exception:
        info["hostname"] = "unknown"

    # IP local
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        info["local_ip"] = s.getsockname()[0]
        s.close()
    except Exception:
        info["local_ip"] = "unknown"

    # SO
    try:
        import platform
        info["os"] = platform.system()
        info["os_version"] = platform.version()
        info["architecture"] = platform.machine()
        info["python_version"] = platform.python_version()
    except Exception:
        pass

    # Memória
    try:
        with open('/proc/meminfo', 'r') as f:
            for line in f:
                if line.startswith('MemTotal:'):
                    info["total_memory"] = line.split()[1] + " kB"
                elif line.startswith('MemAvailable:'):
                    info["available_memory"] = line.split()[1] + " kB"
    except Exception:
        pass

    # CPUs
    try:
        import subprocess
        result = subprocess.run(['nproc'], capture_output=True, text=True)
        info["cpu_count"] = int(result.stdout.strip())
    except Exception:
        info["cpu_count"] = "unknown"

    return info


def check_internet_connection() -> bool:
    """Verifica conexão com a internet."""
    try:
        socket.create_connection(("8.8.8.8", 53), timeout=3)
        return True
    except (socket.error, socket.timeout):
        return False


def safe_file_read(file_path: str, max_size: int = 10 * 1024 * 1024) -> Optional[bytes]:
    """Leitura segura de arquivo com limite de tamanho."""
    try:
        stat = os.stat(file_path)
        if stat.st_size > max_size:
            return None
        with open(file_path, 'rb') as f:
            return f.read()
    except (IOError, OSError, PermissionError):
        return None


def generate_report_filename(prefix: str = "sentinel") -> str:
    """Gera nome de arquivo para relatório."""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    return f"{prefix}_report_{timestamp}"


def calculate_entropy(data: bytes) -> float:
    """Calcula entropia de Shannon dos dados."""
    if not data:
        return 0.0

    byte_counts = [0] * 256
    for byte in data:
        byte_counts[byte] += 1

    length = len(data)
    entropy = 0.0

    for count in byte_counts:
        if count > 0:
            probability = count / length
            entropy -= probability * __import__('math').log2(probability)

    return entropy


def is_likely_encrypted(data: bytes, entropy_threshold: float = 7.5) -> bool:
    """Verifica se os dados provavelmente estão criptografados."""
    if len(data) < 64:
        return False

    entropy = calculate_entropy(data)
    return entropy > entropy_threshold


def sanitize_path(path: str) -> str:
    """Sanitiza um caminho de arquivo."""
    # Remover caracteres perigosos
    dangerous = ['..', ';', '|', '&', '$', '`']
    for char in dangerous:
        path = path.replace(char, '')
    return os.path.normpath(path)


def get_file_type_info(file_path: str) -> Dict:
    """Obtém informações sobre o tipo de arquivo."""
    info = {"path": file_path, "type": "unknown", "mime": "unknown"}

    try:
        # Ler magic bytes
        with open(file_path, 'rb') as f:
            header = f.read(16)

        # Identificar tipo
        type_map = {
            (b'MZ',): "PE Executable",
            (b'\x7fELF',): "ELF Executable",
            (b'%PDF',): "PDF Document",
            (b'PK\x03\x04',): "ZIP Archive",
            (b'\x89PNG',): "PNG Image",
            (b'\xff\xd8\xff',): "JPEG Image",
            (b'GIF8',): "GIF Image",
            (b'\x1f\x8b',): "GZIP Compressed",
            (b'\xfd7zXZ',): "XZ Compressed",
            (b'BZh',): "BZIP2 Compressed",
            (b'Rar!\x1a\x07',): "RAR Archive",
            (b'\x50\x4b\x05\x06',): "ZIP (empty)",
        }

        for signatures, file_type in type_map.items():
            for sig in signatures:
                if header.startswith(sig):
                    info["type"] = file_type
                    break

        # Tentar mime type
        try:
            import mimetypes
            mime = mimetypes.guess_type(file_path)[0]
            if mime:
                info["mime"] = mime
        except Exception:
            pass

    except (IOError, OSError):
        pass

    return info
