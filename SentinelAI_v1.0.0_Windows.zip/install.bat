@echo off
REM ============================================================
REM Sentinel AI - Instalador para Windows
REM Versão 1.0.0
REM ============================================================

title Sentinel AI - Instalador
color 0A

echo.
echo ============================================================
echo   SENTINEL AI - Sistema de Segurança Inteligente
echo   Instalador para Windows
echo ============================================================
echo.

REM Verificar se Python está instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python não encontrado no sistema.
    echo.
    echo O Sentinel AI requer Python 3.8 ou superior.
    echo.
    echo Baixe e instale o Python em: https://www.python.org/downloads/
    echo.
    echo IMPORTANTE: Durante a instalação, marque a opção "Add Python to PATH"
    echo.
    pause
    exit /b 1
)

echo [OK] Python encontrado:
python --version
echo.

REM Verificar versão do Python
python -c "import sys; exit(0 if sys.version_info >= (3, 8) else 1)"
if errorlevel 1 (
    echo [ERRO] Python versão 3.8 ou superior é necessário.
    echo Sua versão atual:
    python --version
    pause
    exit /b 1
)

echo [OK] Versão do Python compatível.
echo.

REM Criar diretório de instalação
set "INSTALL_DIR=%APPDATA%\SentinelAI"
echo Instalando em: %INSTALL_DIR%
mkdir "%INSTALL_DIR%" 2>nul

REM Copiar arquivos do projeto
echo.
echo [1/4] Copiando arquivos do sistema...
xcopy /E /I /Y "sentinel_ai" "%INSTALL_DIR%\sentinel_ai"
if errorlevel 1 (
    echo [ERRO] Falha ao copiar arquivos.
    pause
    exit /b 1
)
echo [OK] Arquivos copiados com sucesso.

REM Instalar dependências
echo.
echo [2/4] Instalando dependências...
python -m pip install customtkinter --quiet --user
if errorlevel 1 (
    echo [AVISO] Falha ao instalar customtkinter via pip.
    echo Tentando com pip...
    pip install customtkinter --quiet --user
)
echo [OK] Dependências instaladas.

REM Criar atalho
echo.
echo [3/4] Criando atalho na Área de Trabalho...

python -c "
import os, sys
import ctypes, sys

desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
start_menu = os.path.join(os.environ.get('APPDATA', ''), 'Microsoft\\Windows\\Start Menu\\Programs')

launcher_bat = os.path.join(sys.argv[1], 'launcher.bat')
with open(launcher_bat, 'w') as f:
    f.write('@echo off\n')
    f.write('title Sentinel AI\n')
    f.write('color 0A\n')
    f.write('cd /d \"%APPDATA%\\SentinelAI\"\n')
    f.write('python -m sentinel_ai.main --gui\n')
    f.write('pause\n')

desktop_shortcut = os.path.join(desktop, 'Sentinel AI.lnk')
if os.path.exists(launcher_bat):
    try:
        import winreg
        # Criar entrada no registro para iniciar automaticamente
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, 
                            'Software\\Microsoft\\Windows\\CurrentVersion\\Run',
                            0, winreg.KEY_WRITE)
        winreg.SetValueEx(key, 'SentinelAI', 0, winreg.REG_SZ, launcher_bat)
        winreg.CloseKey(key)
        print('Configurado para iniciar automaticamente.')
    except Exception:
        pass

# Criar atalho simples via script VB
vbs_path = os.path.join(sys.argv[1], 'create_shortcut.vbs')
with open(vbs_path, 'w') as f:
    f.write('Set oWS = WScript.CreateObject(\"WScript.Shell\")\n')
    f.write('sLinkFile = \"' + desktop_shortcut + '\"\n')
    f.write('Set oLink = oWS.CreateShortcut(sLinkFile)\n')
    f.write('oLink.TargetPath = \"' + launcher_bat + '\"\n')
    f.write('oLink.WorkingDirectory = \"' + sys.argv[1] + '\"\n')
    f.write('oLink.IconLocation = \"shell32.dll,25\"\n')
    f.write('oLink.Description = \"Sentinel AI - Sistema de Segurança\"\n')
    f.write('oLink.Save\n')

os.system('cscript //nologo \"' + vbs_path + '\"')
print('Atalho criado na Área de Trabalho.')
" "%INSTALL_DIR%" 2>nul

echo [OK] Atalho criado.

REM Criar desinstalador
echo.
echo [4/4] Criando desinstalador...

python -c "
import os, sys

uninstall_bat = os.path.join(sys.argv[1], 'uninstall.bat')
with open(uninstall_bat, 'w') as f:
    f.write('@echo off\n')
    f.write('echo.\n')
    f.write('echo ============================================================\n')
    f.write('echo   Sentinel AI - Desinstalador\n')
    f.write('echo ============================================================\n')
    f.write('echo.\n')
    f.write('echo Removendo arquivos...\n')
    f.write('rd /s /q \"%%APPDATA%%\\SentinelAI\" 2>nul\n')
    f.write('del /f /q \"%%USERPROFILE%%\\Desktop\\Sentinel AI.lnk\" 2>nul\n')
    f.write('echo.\n')
    f.write('echo [OK] Sentinel AI removido com sucesso.\n')
    f.write('echo.\n')
    f.write('pause\n')
" "%INSTALL_DIR%"

echo [OK] Desinstalador criado.

REM Mensagem final
echo.
echo ============================================================
echo   INSTALAÇÃO CONCLUÍDA COM SUCESSO!
echo ============================================================
echo.
echo   O Sentinel AI foi instalado em:
echo   %INSTALL_DIR%
echo.
echo   Para iniciar:
echo   1. Use o atalho na Área de Trabalho
echo   2. Ou execute: python -m sentinel_ai.main --gui
echo      no diretório de instalação
echo.
echo   O programa foi configurado para iniciar automaticamente
echo   com o Windows.
echo.
echo   Para desinstalar, execute uninstall.bat no diretório.
echo.
echo ============================================================
echo.
pause
