#!/bin/bash
# ============================================================
# Sentinel AI - Instalador para Linux
# Versão 1.0.0
# ============================================================

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
YELLOW='\033[1;33m'
NC='\033[0m'

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "  ${BLUE}SENTINEL AI${NC} - Sistema de Segurança Inteligente"
echo -e "  ${BLUE}Instalador para Linux${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""

# Verificar se é root ou usando sudo
if [ "$EUID" -eq 0 ]; then
    echo -e "${RED}[AVISO] Não execute este script como root.${NC}"
    echo "Instale como usuário normal com sudo."
    exit 1
fi

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}[ERRO] Python 3 não encontrado.${NC}"
    echo ""
    echo "Instale Python 3.8+ com:"
    echo "  Ubuntu/Debian: sudo apt install python3 python3-pip"
    echo "  Fedora: sudo dnf install python3 python3-pip"
    echo "  Arch: sudo pacman -S python python-pip"
    exit 1
fi

PYTHON_VERSION=$(python3 -c "import sys; print(f'{sys.version_info.major}.{sys.version_info.minor}')")
echo -e "${GREEN}[OK]${NC} Python encontrado: $PYTHON_VERSION"

# Verificar versão mínima
MINOR_VERSION=$(echo "$PYTHON_VERSION" | cut -d. -f2)
if [ "$(echo "$PYTHON_VERSION" | cut -d. -f1)" -lt 3 ] || \
   ([ "$(echo "$PYTHON_VERSION" | cut -d. -f1)" -eq 3 ] && [ "$MINOR_VERSION" -lt 8 ]); then
    echo -e "${RED}[ERRO] Python 3.8 ou superior é necessário.${NC}"
    exit 1
fi

# Verificar pip
if ! command -v pip3 &> /dev/null && ! python3 -m pip --version &> /dev/null; then
    echo -e "${RED}[ERRO] pip não encontrado.${NC}"
    echo "Instale com: sudo apt install python3-pip"
    exit 1
fi

echo ""
echo -e "${GREEN}[1/4]${NC} Criando diretório de instalação..."

# Determinar diretório de instalação
INSTALL_DIR="$HOME/.sentinel_ai"
mkdir -p "$INSTALL_DIR"

echo -e "${GREEN}[2/4]${NC} Copiando arquivos do sistema..."
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp -r "$SCRIPT_DIR/sentinel_ai" "$INSTALL_DIR/"
echo -e "${GREEN}[OK]${NC} Arquivos copiados."

echo ""
echo -e "${GREEN}[3/4]${NC} Instalando dependências..."
pip3 install customtkinter --quiet --user
echo -e "${GREEN}[OK]${NC} Dependências instaladas."

echo ""
echo -e "${GREEN}[4/4]${NC} Criando lançadores..."

# Criar script launcher
cat > "$INSTALL_DIR/sentinel-ai.sh" << 'LAUNCHER'
#!/bin/bash
# Sentinel AI - Launcher
cd "$HOME/.sentinel_ai"
python3 -m sentinel_ai.main --gui "$@"
LAUNCHER
chmod +x "$INSTALL_DIR/sentinel-ai.sh"

# Criar atalho .desktop para menu de aplicativos
mkdir -p "$HOME/.local/share/applications"
cat > "$HOME/.local/share/applications/sentinel-ai.desktop" << DESKTOP
[Desktop Entry]
Name=Sentinel AI
Comment=Sistema de Segurança Inteligente
Exec=$INSTALL_DIR/sentinel-ai.sh
Icon=utilities-shield
Terminal=false
Type=Application
Categories=Utility;Security;
DesktopEntry DESKTOP

# Criar alias no bashrc
if ! grep -q "sentinel-ai" "$HOME/.bashrc" 2>/dev/null; then
    echo "" >> "$HOME/.bashrc"
    echo "# Sentinel AI" >> "$HOME/.bashrc"
    echo "alias sentinel-ai='$INSTALL_DIR/sentinel-ai.sh'" >> "$HOME/.bashrc"
fi

# Criar desinstalador
cat > "$INSTALL_DIR/uninstall.sh" << UNINSTALL
#!/bin/bash
# Sentinel AI - Desinstalador
echo "Removendo Sentinel AI..."
rm -rf "$HOME/.sentinel_ai"
rm -f "$HOME/.local/share/applications/sentinel-ai.desktop"
sed -i '/# Sentinel AI/d' "$HOME/.bashrc"
sed -i '/alias sentinel-ai/d' "$HOME/.bashrc"
echo "Sentinel AI removido com sucesso."
UNINSTALL
chmod +x "$INSTALL_DIR/uninstall.sh"

echo -e "${GREEN}[OK]${NC} Lançadores criados."

echo ""
echo -e "${BLUE}============================================================${NC}"
echo -e "  ${GREEN}INSTALAÇÃO CONCLUÍDA COM SUCESSO!${NC}"
echo -e "${BLUE}============================================================${NC}"
echo ""
echo "  O Sentinel AI foi instalado em:"
echo "  $INSTALL_DIR"
echo ""
echo "  Para iniciar:"
echo "  1. Execute: sentinel-ai"
echo "  2. Ou: $INSTALL_DIR/sentinel-ai.sh"
echo "  3. Ou procure 'Sentinel AI' no menu de aplicativos"
echo ""
echo "  Para desinstalar:"
echo "  $INSTALL_DIR/uninstall.sh"
echo ""
echo -e "${BLUE}============================================================${NC}"
echo ""
