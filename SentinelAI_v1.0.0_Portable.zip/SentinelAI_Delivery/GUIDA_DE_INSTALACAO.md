# Sentinel AI v1.0.0 - Guia de Instalação

## Pacotes Disponíveis

| Arquivo | Plataforma | Descrição |
|---------|-----------|-----------|
| `SentinelAI_v1.0.0_Windows.zip` | Windows | Pacote para Windows com instalador automático |
| `SentinelAI_v1.0.0_Linux.zip` | Linux | Pacote para Linux com instalador automático |
| `SentinelAI_v1.0.0_Full.zip` | Ambos | Pacote completo com instaladores para ambas plataformas |

---

## Windows

### Instalação Automática (Recomendado)
1. Extraia o arquivo `SentinelAI_v1.0.0_Windows.zip`
2. Execute `install.bat`
3. O programa será instalado automaticamente com atalho na Área de Trabalho e configuração para iniciar com o Windows

### Instalação Manual
1. Extraia o ZIP em qualquer pasta
2. Instale Python 3.8+ de [https://www.python.org/downloads/](https://www.python.org/downloads/)
   - **IMPORTANTE**: Marque "Add Python to PATH" durante a instalação
3. Execute `start.bat` na pasta extraída

### Execução via Linha de Comando
```batch
cd C:\caminho\para\sentinel_ai
python -m sentinel_ai.main
```

---

## Linux

### Instalação Automática
1. Extraia o arquivo `SentinelAI_v1.0.0_Linux.zip`
2. Execute:
```bash
chmod +x install.sh && ./install.sh
```
3. O programa será instalado com atalho no menu de aplicativos

### Instalação Manual
1. Extraia o ZIP em qualquer pasta
2. Execute:
```bash
chmod +x start.sh && ./start.sh
```

### Via Pip
```bash
cd sentinel_ai/
pip install .
sentinel-ai
```

---

## Comandos Disponíveis

| Comando | Descrição |
|---------|-----------|
| `python -m sentinel_ai.main` | Interface Gráfica (padrão) |
| `--gui` | Forçar Interface Gráfica |
| `--cli scan` | Scan Completo |
| `--cli quick` | Scan Rápido |
| `--cli monitor` | Monitoramento em Tempo Real |
| `--cli status` | Status do Sistema |
| `--cli config` | Mostrar Configuração |

---

## Requisitos do Sistema

- **Python**: 3.8 ou superior
- **Sistema**: Windows 10/11 ou Linux (Ubuntu 18.04+)
- **Espaço**: 150MB de disco livre
- **Internet**: Necessária apenas para a instalação inicial

---

## Desinstalação

**Windows**: Execute `uninstall.bat` no diretório de instalação (normalmente `%APPDATA%\SentinelAI`)

**Linux**: Execute `uninstall.sh` no diretório de instalação (normalmente `~/.sentinel_ai`)
